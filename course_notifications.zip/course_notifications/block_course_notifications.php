<?php

class block_course_notifications extends block_base {
    public function init() {
        $this->title = get_string('pluginname', 'block_course_notifications');
    }

    /**
     * Permite múltiples instancias del bloque en una misma página (ej. curso).
     * @return bool
     */
    public function instance_allow_multiple() {
        return true;
    }

    /**
     * Define en qué tipos de páginas puede aparecer este bloque.
     * Aquí lo limitamos a páginas de vista de curso.
     * @return array
     */
    public function applicable_formats() {
        return ['course-view' => true, 'site' => false, 'my' => false, 'mod' => false];
    }

    /**
     * Indica si el bloque tiene configuraciones específicas por instancia.
     * Si es true, Moodle buscará un edit_form.php.
     * @return bool
     */
    public function has_config() {
        return true;
    }

    /**
     * Controla lo que se muestra en el contenido del bloque.
     * Por ahora, lo dejaremos simple. Podrías mostrar aquí un resumen
     * de la configuración o estado si lo deseas.
     * @return stdClass|null
     */
    public function get_content() {
        if ($this->content !== null) {
            return $this->content;
        }

        $this->content = new stdClass;
        $this->content->text = ''; // Puedes poner aquí texto informativo
        $this->content->footer = '';

        if (empty($this->instance)) {
            return $this->content;
        }
        
        // Ejemplo de acceso a la configuración (si la necesitaras mostrar en el bloque)
        // $isenabled = get_config('block_course_notifications', 'enable_start_email_' . $this->instance->id); // Incorrecto para config de instancia
        // if (!empty($this->config) && !empty($this->config->enable_start_email)) {
        //    $this->content->text = get_string('start_email_enabled_desc', 'block_course_notifications');
        // } else {
        //    $this->content->text = get_string('start_email_disabled_desc', 'block_course_notifications');
        // }

        return $this->content;
    }

    /**
     * Se llama después de que el formulario de configuración de la instancia se guarda.
     * Aquí es donde puedes procesar los datos antes de que se guarden.
     * Moodle guarda los datos de configuración de la instancia serializados
     * en la columna `configdata` de la tabla `block_instances`.
     *
     * @param stdClass $data Los datos del formulario (los nombres de los campos ya tienen 'config_')
     * @param bool $nolongerused No usado en bloques modernos.
     * @return bool
     */
    public function instance_config_save($data, $nolongerused = false) {
        // Moodle espera que los datos se guarden en $this->config (que es un objeto).
        // Los datos que vienen de $data ya tienen el prefijo 'config_'.
        // Moodle se encarga de mapearlos a $this->config->nombre_sin_prefijo.

        // Por ejemplo, si tu formulario tiene un campo 'config_enable_something',
        // se guardará como $this->config->enable_something.

        // Para el editor, Moodle espera un array con 'text' y 'format'.
        // Sin embargo, al guardar en configdata, es más simple guardar solo el texto.
        // Si se guarda solo el texto, asegúrate de que set_data en edit_form lo maneje.

        // Si el editor devuelve un array ['text' => ..., 'format' => ...],
        // y quieres guardar solo el texto:
        if (isset($data->config_start_email_body) && is_array($data->config_start_email_body)) {
             $data->config_start_email_body = $data->config_start_email_body['text'];
        }
        
        // Si quieres guardar el objeto completo del editor (texto y formato):
        // No hagas nada especial aquí, Moodle lo guardará tal cual.
        // Solo asegúrate de que la tarea cron y set_data lo esperan así.

        return parent::instance_config_save($data, $nolongerused);
    }

    /**
     * Oculta la cabecera del bloque si el título está vacío y no hay contenido.
     * Útil si el bloque es solo para configuración y no muestra nada visible.
     * @return bool
     */
    // public function hide_header() {
    //     return empty($this->config->title) && empty($this->content->text) && empty($this->content->footer);
    // }
}