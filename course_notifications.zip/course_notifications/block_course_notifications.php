<?php

class block_course_notifications extends block_base {
    public function init() {
        $this->title = get_string('pluginname', 'block_course_notifications');
    }

    /**
     * Permite múltiples instancias del bloque en una misma página (ej. curso).
     * @return bool
     */
    public function instance_allow_multiple() {
        return true;
    }

    /**
     * Define en qué tipos de páginas puede aparecer este bloque.
     * Aquí lo limitamos a páginas de vista de curso.
     * @return array
     */
    public function applicable_formats() {
        return ['course-view' => true, 'site' => false, 'my' => false, 'mod' => false];
    }

    /**
     * Indica si el bloque tiene configuraciones específicas por instancia.
     * Si es true, Moodle buscará un edit_form.php.
     * @return bool
     */
    public function has_config() {
        return true;
    }

    /**
     * Controla lo que se muestra en el contenido del bloque.
     * Por ahora, lo dejaremos simple. Podrías mostrar aquí un resumen
     * de la configuración o estado si lo deseas.
     * @return stdClass|null
     */
    public function get_content() {
        if ($this->content !== null) {
            return $this->content;
        }

        $this->content = new stdClass;
        $this->content->text = ''; // Puedes poner aquí texto informativo
        $this->content->footer = '';

        if (empty($this->instance)) {
            return $this->content;
        }
        
        // Ejemplo de acceso a la configuración (si la necesitaras mostrar en el bloque)
        // $isenabled = get_config('block_course_notifications', 'enable_start_email_' . $this->instance->id); // Incorrecto para config de instancia
        // if (!empty($this->config) && !empty($this->config->enable_start_email)) {
        //    $this->content->text = get_string('start_email_enabled_desc', 'block_course_notifications');
        // } else {
        //    $this->content->text = get_string('start_email_disabled_desc', 'block_course_notifications');
        // }

        return $this->content;
    }

    /**
     * Se llama después de que el formulario de configuración de la instancia se guarda.
     * Aquí es donde puedes procesar los datos antes de que se guarden.
     * Moodle guarda los datos de configuración de la instancia serializados
     * en la columna `configdata` de la tabla `block_instances`.
     *
     * @param stdClass $data Los datos del formulario (los nombres de los campos ya tienen 'config_')
     * @param bool $nolongerused No usado en bloques modernos.
     * @return bool
     */
    public function instance_config_save($data, $nolongerused = false) {
        // Para el editor de inicio de curso
        if (isset($data->config_start_email_body) && is_array($data->config_start_email_body)) {
             $data->config_start_email_body = $data->config_start_email_body['text'];
        }

        // Para el editor de progreso del 20%
        if (isset($data->config_progress20_email_body) && is_array($data->config_progress20_email_body)) {
             $data->config_progress20_email_body = $data->config_progress20_email_body['text'];
        }
        
        // Para el nuevo editor de finalización de curso
        if (isset($data->config_completion_email_body) && is_array($data->config_completion_email_body)) { // AÑADIDO
             $data->config_completion_email_body = $data->config_completion_email_body['text']; // AÑADIDO
        }
        
        return parent::instance_config_save($data, $nolongerused);
    }

    /**
     * Oculta la cabecera del bloque si el título está vacío y no hay contenido.
     * Útil si el bloque es solo para configuración y no muestra nada visible.
     * @return bool
     */
    // public function hide_header() {
    //     return empty($this->config->title) && empty($this->content->text) && empty($this->content->footer);
    // }
}