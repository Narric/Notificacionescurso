<?php

class block_course_notifications extends block_base {
    public function init() {
        $this->title = get_string('pluginname', 'block_course_notifications');
    }

    public function instance_allow_multiple() {
        return true;
    }

    public function applicable_formats() {
        return ['course-view' => true, 'site' => false, 'my' => false, 'mod' => false];
    }

    public function has_config() {
        return true;
    }

    public function get_content() {
        if ($this->content !== null) {
            return $this->content;
        }

        $this->content = new stdClass;
        $this->content->text = ''; 
        $this->content->footer = '';

        // El contenido del bloque es mínimo, ya que su propósito principal es la configuración
        // y las tareas en segundo plano.

        return $this->content;
    }

    /**
     * Se llama después de que el formulario de configuración de la instancia se guarda.
     * Aquí es donde puedes procesar los datos antes de que se guarden.
     * Moodle guarda los datos de configuración de la instancia serializados
     * en la columna `configdata` de la tabla `block_instances`.
     *
     * @param stdClass $data Los datos del formulario (los nombres de los campos ya tienen 'config_')
     * @param bool $nolongerused No usado en bloques modernos.
     * @return bool
     */
    public function instance_config_save($data, $nolongerused = false) {
        // Para el editor de inicio de curso
        if (isset($data->config_start_email_body) && is_array($data->config_start_email_body)) {
            $data->config_start_email_body = $data->config_start_email_body['text'];
        }

        // Para el editor de progreso del 20%
        if (isset($data->config_progress20_email_body) && is_array($data->config_progress20_email_body)) {
            $data->config_progress20_email_body = $data->config_progress20_email_body['text'];
        }
        
        // Para el editor de finalización de curso
        if (isset($data->config_completion_email_body) && is_array($data->config_completion_email_body)) {
            $data->config_completion_email_body = $data->config_completion_email_body['text'];
        }

        // NUEVO: Para el editor de recordatorio de BigBlueButton
        if (isset($data->config_bbb_reminder_email_body) && is_array($data->config_bbb_reminder_email_body)) {
            $data->config_bbb_reminder_email_body = $data->config_bbb_reminder_email_body['text'];
        }
        
        // Los checkboxes (como config_enable_start_email, config_enable_bbb_reminder_email, etc.)
        // se envían como '1' si están marcados, o no se envían si no lo están (a menos que estén "congelados" o tengan un valor por defecto).
        // El formulario (edit_form.php) usa setDefault(..., 0) para los checkboxes,
        // por lo que si no están marcados, $data->config_nombre_del_checkbox debería ser '0'.
        // Si están marcados, será '1'. No se necesita procesamiento adicional aquí para ellos
        // si el formulario está configurado correctamente con setDefault.

        // El método padre instance_config_save se encargará de:
        // 1. Iterar sobre las propiedades del objeto $data.
        // 2. Para cada propiedad que comience con 'config_', quitar ese prefijo.
        // 3. Usar la clave sin prefijo y el valor para poblar $this->config.
        // 4. Serializar $this->config y guardarlo en la base de datos.
        return parent::instance_config_save($data, $nolongerused);
    }
}