<?php

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/formslib.php');

class block_course_notifications_edit_form extends block_edit_form {

    protected function specific_definition($mform) {
        global $CFG; // $DB no suele ser necesario aquí a menos que cargues datos para el form.

        // Sección para la configuración de notificación de inicio de curso.
        $mform->addElement('header', 'coursestartheader', get_string('coursestartsettings', 'block_course_notifications'));

        // Checkbox para habilitar/deshabilitar el envío de correo al inicio.
        $mform->addElement('checkbox', 'config_enable_start_email', get_string('enablestartemail', 'block_course_notifications'));
        $mform->setDefault('config_enable_start_email', 0); // Por defecto deshabilitado.
        $mform->addHelpButton('config_enable_start_email', 'enablestartemail_help', 'block_course_notifications');

        // Campo de texto para el asunto del correo.
        $mform->addElement('text', 'config_start_email_subject', get_string('startemailsubject', 'block_course_notifications'));
        $mform->setType('config_start_email_subject', PARAM_TEXT);
        $mform->setDefault('config_start_email_subject', get_string('defaultstartemailsubject', 'block_course_notifications'));
        // Se podría añadir una regla de dependencia si el checkbox está marcado,
        // pero es más complejo y a menudo se maneja con JS o validación en el servidor.
        // $mform->addRule('config_start_email_subject', null, 'required', null, 'client'); // Requerido si el checkbox está activo
        $mform->addHelpButton('config_start_email_subject', 'startemailsubject_help', 'block_course_notifications');
        // Regla para hacer el campo obligatorio si el checkbox está marcado
        $mform->addRule('config_start_email_subject', get_string('required'), 'required', null, 'client', false, false, array('config_enable_start_email'));
        $mform->addRule('config_start_email_subject', get_string('required'), 'required', null, 'server', false, false, array('config_enable_start_email'));


        // Editor HTML para el cuerpo del correo.
        // Los campos del editor deben definirse esperando un array ['text' => ..., 'format' => ...].
        $editoroptions = ['maxfiles' => EDITOR_UNLIMITED_FILES, 'maxbytes' => $CFG->maxbytes, 'trusttext' => true, 'context' => $this->block->context];
        $mform->addElement('editor', 'config_start_email_body', get_string('startemailbody', 'block_course_notifications'), null, $editoroptions);
        $mform->setType('config_start_email_body', PARAM_RAW); // PARAM_RAW porque el editor maneja la limpieza.
        $mform->setDefault('config_start_email_body', [
            'text' => get_string('defaultstartemailbody', 'block_course_notifications'),
            'format' => FORMAT_HTML
        ]);
        $mform->addHelpButton('config_start_email_body', 'startemailbody_help', 'block_course_notifications');
        // Regla para hacer el campo obligatorio si el checkbox está marcado
        $mform->addRule('config_start_email_body', get_string('required'), 'required', null, 'client', false, false, array('config_enable_start_email'));
        $mform->addRule('config_start_email_body', get_string('required'), 'required', null, 'server', false, false, array('config_enable_start_email'));

        // Sección para la configuración de notificación de recordatorio de progreso del 20%. // Cambiado comentario
        $mform->addElement('header', 'progressreminderheader', get_string('progressremindersettings', 'block_course_notifications')); // La clave del string ya fue actualizada en el lang file

        // Checkbox para habilitar/deshabilitar el envío de correo de recordatorio del 20%.
        $mform->addElement('checkbox', 'config_enable_progress20_email', get_string('enableprogress20email', 'block_course_notifications')); // Cambiado nombre de campo y clave de string
        $mform->setDefault('config_enable_progress20_email', 0); // Cambiado nombre de campo
        $mform->addHelpButton('config_enable_progress20_email', 'enableprogress20email_help', 'block_course_notifications'); // Cambiado nombre de campo y clave de string

        // Campo de texto para el asunto del correo de recordatorio del 20%.
        $mform->addElement('text', 'config_progress20_email_subject', get_string('progress20emailsubject', 'block_course_notifications')); // Cambiado nombre de campo y clave de string
        $mform->setType('config_progress20_email_subject', PARAM_TEXT); // Cambiado nombre de campo
        $mform->setDefault('config_progress20_email_subject', get_string('defaultprogress20subject', 'block_course_notifications')); // Cambiado nombre de campo y clave de string
        $mform->addHelpButton('config_progress20_email_subject', 'progress20emailsubject_help', 'block_course_notifications'); // Cambiado nombre de campo y clave de string
        // Regla para hacer el campo obligatorio si el checkbox está marcado
        $mform->addRule('config_progress20_email_subject', get_string('required'), 'required', null, 'client', false, false, array('config_enable_progress20_email')); // Cambiado nombre de campo
        $mform->addRule('config_progress20_email_subject', get_string('required'), 'required', null, 'server', false, false, array('config_enable_progress20_email')); // Cambiado nombre de campo

        // Editor HTML para el cuerpo del correo de recordatorio del 20%.
        $mform->addElement('editor', 'config_progress20_email_body', get_string('progress20emailbody', 'block_course_notifications'), null, $editoroptions); // Cambiado nombre de campo y clave de string
        $mform->setType('config_progress20_email_body', PARAM_RAW); // Cambiado nombre de campo
        $mform->setDefault('config_progress20_email_body', [ // Cambiado nombre de campo
            'text' => get_string('defaultprogress20body', 'block_course_notifications'), // Clave de string
            'format' => FORMAT_HTML
        ]);
        $mform->addHelpButton('config_progress20_email_body', 'progress20emailbody_help', 'block_course_notifications'); // Cambiado nombre de campo y clave de string
        // Regla para hacer el campo obligatorio si el checkbox está marcado
        $mform->addRule('config_progress20_email_body', get_string('required'), 'required', null, 'client', false, false, array('config_enable_progress20_email')); // Cambiado nombre de campo
        $mform->addRule('config_progress20_email_body', get_string('required'), 'required', null, 'server', false, false, array('config_enable_progress20_email')); // Cambiado nombre de campo
        
        // Sección para la configuración de notificación de finalización de curso.
        $mform->addElement('header', 'coursecompletionheader', get_string('coursecompletionsettings', 'block_course_notifications'));

        $mform->addElement('checkbox', 'config_enable_completion_email', get_string('enablecompletionemail', 'block_course_notifications'));
        $mform->setDefault('config_enable_completion_email', 0);
        $mform->addHelpButton('config_enable_completion_email', 'enablecompletionemail_help', 'block_course_notifications');

        $mform->addElement('text', 'config_completion_email_subject', get_string('completionemailsubject', 'block_course_notifications'));
        $mform->setType('config_completion_email_subject', PARAM_TEXT);
        $mform->setDefault('config_completion_email_subject', get_string('defaultcompletionsubject', 'block_course_notifications'));
        $mform->addHelpButton('config_completion_email_subject', 'completionemailsubject_help', 'block_course_notifications');
        $mform->addRule('config_completion_email_subject', get_string('required'), 'required', null, 'client', false, false, array('config_enable_completion_email'));
        $mform->addRule('config_completion_email_subject', get_string('required'), 'required', null, 'server', false, false, array('config_enable_completion_email'));

        // $editoroptions ya está definido arriba en tu archivo.
        $mform->addElement('editor', 'config_completion_email_body', get_string('completionemailbody', 'block_course_notifications'), null, $editoroptions);
        $mform->setType('config_completion_email_body', PARAM_RAW);
        $mform->setDefault('config_completion_email_body', [
            'text' => get_string('defaultcompletionbody', 'block_course_notifications'),
            'format' => FORMAT_HTML
        ]);
        $mform->addHelpButton('config_completion_email_body', 'completionemailbody_help', 'block_course_notifications');
        $mform->addRule('config_completion_email_body', get_string('required'), 'required', null, 'client', false, false, array('config_enable_completion_email'));
        $mform->addRule('config_completion_email_body', get_string('required'), 'required', null, 'server', false, false, array('config_enable_completion_email'));
    }

    /**
     * Carga los datos existentes en el formulario.
     * Es crucial para que el editor de texto muestre el contenido guardado.
     * @param stdClass $defaults Valores por defecto a cargar.
     */
    public function set_data($defaults) {
        if (is_object($defaults) && !empty($this->block->config)) {
            foreach ($this->block->config as $key => $value) {
                $configname = 'config_' . $key;

                // Manejo especial para campos de editor
                if ($key === 'start_email_body' || $key === 'progress20_email_body' || $key === 'completion_email_body') { // AÑADIDO 'completion_email_body'
                    if (is_string($value)) {
                        $defaults->$configname = ['text' => $value, 'format' => FORMAT_HTML];
                    } else if (is_array($value) && isset($value['text'])) {
                        $defaults->$configname = $value;
                    } else if (is_object($value) && isset($value->text)) {
                        $defaults->$configname = (array)$value;
                    } else {
                         $defaults->$configname = ['text' => '', 'format' => FORMAT_HTML];
                    }
                }
            }
        }
        parent::set_data($defaults);
    }
}