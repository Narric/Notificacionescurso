<?php

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/formslib.php');

class block_course_notifications_edit_form extends block_edit_form {

    protected function specific_definition($mform) {
        global $CFG; // $DB no suele ser necesario aquí a menos que cargues datos para el form.

        // Sección para la configuración de notificación de inicio de curso.
        $mform->addElement('header', 'coursestartheader', get_string('coursestartsettings', 'block_course_notifications'));

        // Checkbox para habilitar/deshabilitar el envío de correo al inicio.
        $mform->addElement('checkbox', 'config_enable_start_email', get_string('enablestartemail', 'block_course_notifications'));
        $mform->setDefault('config_enable_start_email', 0); // Por defecto deshabilitado.
        $mform->addHelpButton('config_enable_start_email', 'enablestartemail_help', 'block_course_notifications');

        // Campo de texto para el asunto del correo.
        $mform->addElement('text', 'config_start_email_subject', get_string('startemailsubject', 'block_course_notifications'));
        $mform->setType('config_start_email_subject', PARAM_TEXT);
        $mform->setDefault('config_start_email_subject', get_string('defaultstartemailsubject', 'block_course_notifications'));
        // Se podría añadir una regla de dependencia si el checkbox está marcado,
        // pero es más complejo y a menudo se maneja con JS o validación en el servidor.
        // $mform->addRule('config_start_email_subject', null, 'required', null, 'client'); // Requerido si el checkbox está activo
        $mform->addHelpButton('config_start_email_subject', 'startemailsubject_help', 'block_course_notifications');
        // Regla para hacer el campo obligatorio si el checkbox está marcado
        $mform->addRule('config_start_email_subject', get_string('required'), 'required', null, 'client', false, false, array('config_enable_start_email'));
        $mform->addRule('config_start_email_subject', get_string('required'), 'required', null, 'server', false, false, array('config_enable_start_email'));


        // Editor HTML para el cuerpo del correo.
        // Los campos del editor deben definirse esperando un array ['text' => ..., 'format' => ...].
        $editoroptions = ['maxfiles' => EDITOR_UNLIMITED_FILES, 'maxbytes' => $CFG->maxbytes, 'trusttext' => true, 'context' => $this->block->context];
        $mform->addElement('editor', 'config_start_email_body', get_string('startemailbody', 'block_course_notifications'), null, $editoroptions);
        $mform->setType('config_start_email_body', PARAM_RAW); // PARAM_RAW porque el editor maneja la limpieza.
        $mform->setDefault('config_start_email_body', [
            'text' => get_string('defaultstartemailbody', 'block_course_notifications'),
            'format' => FORMAT_HTML
        ]);
        $mform->addHelpButton('config_start_email_body', 'startemailbody_help', 'block_course_notifications');
        // Regla para hacer el campo obligatorio si el checkbox está marcado
        $mform->addRule('config_start_email_body', get_string('required'), 'required', null, 'client', false, false, array('config_enable_start_email'));
        $mform->addRule('config_start_email_body', get_string('required'), 'required', null, 'server', false, false, array('config_enable_start_email'));

        // Puedes añadir más campos de configuración aquí para futuras funcionalidades.
    }

    /**
     * Carga los datos existentes en el formulario.
     * Es crucial para que el editor de texto muestre el contenido guardado.
     * @param stdClass $defaults Valores por defecto a cargar.
     */
    public function set_data($defaults) {
        // Los datos de configuración de la instancia se guardan en $this->config
        // (ej. $this->config->enable_start_email).
        // Los nombres de los campos en el formulario son 'config_enable_start_email'.
        // Moodle maneja este mapeo automáticamente para la mayoría de los campos.

        // Sin embargo, para el editor, es importante asegurarse de que los datos
        // se pasen en el formato esperado: un array ['text' => ..., 'format' => ...].

        if (is_object($defaults) && !empty($this->block->config)) {
            foreach ($this->block->config as $key => $value) {
                $configname = 'config_' . $key;
                if ($key === 'start_email_body') { // El nombre de la propiedad en $this->config
                    // Si 'start_email_body' se guardó solo como texto (HTML)
                    if (is_string($value)) {
                        $defaults->$configname = ['text' => $value, 'format' => FORMAT_HTML];
                    } else if (is_array($value) && isset($value['text'])) { // Si se guardó como array
                        $defaults->$configname = $value;
                    } else if (is_object($value) && isset($value->text)) { // Si se guardó como objeto
                        $defaults->$configname = (array)$value;
                    } else { // Por si acaso, para evitar errores
                         $defaults->$configname = ['text' => '', 'format' => FORMAT_HTML];
                    }
                } else {
                    // Para otros campos, Moodle debería mapearlos directamente
                    // si los nombres de los campos del formulario son 'config_' + nombre de la propiedad.
                    // $defaults->$configname = $value; // Esto ya lo hace Moodle
                }
            }
        }
        parent::set_data($defaults);
    }
}