<?php

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/formslib.php');

class block_course_notifications_edit_form extends block_edit_form {

    protected function specific_definition($mform) {
        global $CFG; // $DB no suele ser necesario aquí a menos que cargues datos para el form.

        // Sección para la configuración de notificación de inicio de curso.
        $mform->addElement('header', 'coursestartheader', get_string('coursestartsettings', 'block_course_notifications'));

        // Checkbox para habilitar/deshabilitar el envío de correo al inicio.
        $mform->addElement('checkbox', 'config_enable_start_email', get_string('enablestartemail', 'block_course_notifications'));
        $mform->setDefault('config_enable_start_email', 0); // Por defecto deshabilitado.
        $mform->addHelpButton('config_enable_start_email', 'enablestartemail_help', 'block_course_notifications');

        // Campo de texto para el asunto del correo.
        $mform->addElement('text', 'config_start_email_subject', get_string('startemailsubject', 'block_course_notifications'));
        $mform->setType('config_start_email_subject', PARAM_TEXT);
        $mform->setDefault('config_start_email_subject', get_string('defaultstartemailsubject', 'block_course_notifications'));
        $mform->addHelpButton('config_start_email_subject', 'startemailsubject_help', 'block_course_notifications');
        $mform->addRule('config_start_email_subject', get_string('required', 'block_course_notifications'), 'required', null, 'client', false, false, 'config_enable_start_email'); // Usar la forma correcta de la regla de dependencia
        $mform->addRule('config_start_email_subject', get_string('required', 'block_course_notifications'), 'required', null, 'server', false, false, 'config_enable_start_email');


        // Editor HTML para el cuerpo del correo.
        $editoroptions = ['maxfiles' => EDITOR_UNLIMITED_FILES, 'maxbytes' => $CFG->maxbytes, 'trusttext' => true, 'context' => $this->block->context];
        $mform->addElement('editor', 'config_start_email_body', get_string('startemailbody', 'block_course_notifications'), null, $editoroptions);
        $mform->setType('config_start_email_body', PARAM_RAW); // PARAM_RAW porque el editor maneja la limpieza.
        $mform->setDefault('config_start_email_body', [
            'text' => get_string('defaultstartemailbody', 'block_course_notifications'),
            'format' => FORMAT_HTML
        ]);
        $mform->addHelpButton('config_start_email_body', 'startemailbody_help', 'block_course_notifications');
        $mform->addRule('config_start_email_body', get_string('required', 'block_course_notifications'), 'required', null, 'client', false, false, 'config_enable_start_email');
        $mform->addRule('config_start_email_body', get_string('required', 'block_course_notifications'), 'required', null, 'server', false, false, 'config_enable_start_email');

        // Sección para la configuración de notificación de recordatorio de progreso del 20%.
        $mform->addElement('header', 'progressreminderheader', get_string('progressremindersettings', 'block_course_notifications'));

        $mform->addElement('checkbox', 'config_enable_progress20_email', get_string('enableprogress20email', 'block_course_notifications'));
        $mform->setDefault('config_enable_progress20_email', 0);
        $mform->addHelpButton('config_enable_progress20_email', 'enableprogress20email_help', 'block_course_notifications');

        $mform->addElement('text', 'config_progress20_email_subject', get_string('progress20emailsubject', 'block_course_notifications'));
        $mform->setType('config_progress20_email_subject', PARAM_TEXT);
        $mform->setDefault('config_progress20_email_subject', get_string('defaultprogress20subject', 'block_course_notifications'));
        $mform->addHelpButton('config_progress20_email_subject', 'progress20emailsubject_help', 'block_course_notifications');
        $mform->addRule('config_progress20_email_subject', get_string('required', 'block_course_notifications'), 'required', null, 'client', false, false, 'config_enable_progress20_email');
        $mform->addRule('config_progress20_email_subject', get_string('required', 'block_course_notifications'), 'required', null, 'server', false, false, 'config_enable_progress20_email');

        $mform->addElement('editor', 'config_progress20_email_body', get_string('progress20emailbody', 'block_course_notifications'), null, $editoroptions);
        $mform->setType('config_progress20_email_body', PARAM_RAW);
        $mform->setDefault('config_progress20_email_body', [
            'text' => get_string('defaultprogress20body', 'block_course_notifications'),
            'format' => FORMAT_HTML
        ]);
        $mform->addHelpButton('config_progress20_email_body', 'progress20emailbody_help', 'block_course_notifications');
        $mform->addRule('config_progress20_email_body', get_string('required', 'block_course_notifications'), 'required', null, 'client', false, false, 'config_enable_progress20_email');
        $mform->addRule('config_progress20_email_body', get_string('required', 'block_course_notifications'), 'required', null, 'server', false, false, 'config_enable_progress20_email');
        
        // Sección para la configuración de notificación de finalización de curso.
        $mform->addElement('header', 'coursecompletionheader', get_string('coursecompletionsettings', 'block_course_notifications'));

        $mform->addElement('checkbox', 'config_enable_completion_email', get_string('enablecompletionemail', 'block_course_notifications'));
        $mform->setDefault('config_enable_completion_email', 0);
        $mform->addHelpButton('config_enable_completion_email', 'enablecompletionemail_help', 'block_course_notifications');

        $mform->addElement('text', 'config_completion_email_subject', get_string('completionemailsubject', 'block_course_notifications'));
        $mform->setType('config_completion_email_subject', PARAM_TEXT);
        $mform->setDefault('config_completion_email_subject', get_string('defaultcompletionsubject', 'block_course_notifications'));
        $mform->addHelpButton('config_completion_email_subject', 'completionemailsubject_help', 'block_course_notifications');
        $mform->addRule('config_completion_email_subject', get_string('required', 'block_course_notifications'), 'required', null, 'client', false, false, 'config_enable_completion_email');
        $mform->addRule('config_completion_email_subject', get_string('required', 'block_course_notifications'), 'required', null, 'server', false, false, 'config_enable_completion_email');

        $mform->addElement('editor', 'config_completion_email_body', get_string('completionemailbody', 'block_course_notifications'), null, $editoroptions);
        $mform->setType('config_completion_email_body', PARAM_RAW);
        $mform->setDefault('config_completion_email_body', [
            'text' => get_string('defaultcompletionbody', 'block_course_notifications'),
            'format' => FORMAT_HTML
        ]);
        $mform->addHelpButton('config_completion_email_body', 'completionemailbody_help', 'block_course_notifications');
        $mform->addRule('config_completion_email_body', get_string('required', 'block_course_notifications'), 'required', null, 'client', false, false, 'config_enable_completion_email');
        $mform->addRule('config_completion_email_body', get_string('required', 'block_course_notifications'), 'required', null, 'server', false, false, 'config_enable_completion_email');

        // NUEVO: Sección para la configuración de recordatorio de sesión BigBlueButton.
        $mform->addElement('header', 'bbbreminderheader', get_string('bbbremindersettings', 'block_course_notifications'));

        $mform->addElement('checkbox', 'config_enable_bbb_reminder_email', get_string('enablebbbreminderemail', 'block_course_notifications'));
        $mform->setDefault('config_enable_bbb_reminder_email', 0);
        $mform->addHelpButton('config_enable_bbb_reminder_email', 'enablebbbreminderemail_help', 'block_course_notifications');

        $mform->addElement('text', 'config_bbb_reminder_email_subject', get_string('bbbreminderemailsubject', 'block_course_notifications'));
        $mform->setType('config_bbb_reminder_email_subject', PARAM_TEXT);
        $mform->setDefault('config_bbb_reminder_email_subject', get_string('defaultbbbremindersubject', 'block_course_notifications'));
        $mform->addHelpButton('config_bbb_reminder_email_subject', 'bbbreminderemailsubject_help', 'block_course_notifications');
        $mform->addRule('config_bbb_reminder_email_subject', get_string('required', 'block_course_notifications'), 'required', null, 'client', false, false, 'config_enable_bbb_reminder_email');
        $mform->addRule('config_bbb_reminder_email_subject', get_string('required', 'block_course_notifications'), 'required', null, 'server', false, false, 'config_enable_bbb_reminder_email');

        $mform->addElement('editor', 'config_bbb_reminder_email_body', get_string('bbbreminderemailbody', 'block_course_notifications'), null, $editoroptions);
        $mform->setType('config_bbb_reminder_email_body', PARAM_RAW);
        $mform->setDefault('config_bbb_reminder_email_body', [
            'text' => get_string('defaultbbbreminderbody', 'block_course_notifications'),
            'format' => FORMAT_HTML
        ]);
        $mform->addHelpButton('config_bbb_reminder_email_body', 'bbbreminderemailbody_help', 'block_course_notifications');
        $mform->addRule('config_bbb_reminder_email_body', get_string('required', 'block_course_notifications'), 'required', null, 'client', false, false, 'config_enable_bbb_reminder_email');
        $mform->addRule('config_bbb_reminder_email_body', get_string('required', 'block_course_notifications'), 'required', null, 'server', false, false, 'config_enable_bbb_reminder_email');

    }

    public function set_data($defaults) {
        // Corrección: Asegurar que $this->block->config existe y no está vacío
        if (is_object($defaults) && !empty($this->block->config)) {
            $configdata = $this->block->config; // Usar $this->block->config que es un objeto stdClass

            // Mapear claves de configuración a nombres de formulario
            $fieldmap = [
                'enable_start_email' => 'config_enable_start_email',
                'start_email_subject' => 'config_start_email_subject',
                'start_email_body' => 'config_start_email_body',
                'enable_progress20_email' => 'config_enable_progress20_email',
                'progress20_email_subject' => 'config_progress20_email_subject',
                'progress20_email_body' => 'config_progress20_email_body',
                'enable_completion_email' => 'config_enable_completion_email',
                'completion_email_subject' => 'config_completion_email_subject',
                'completion_email_body' => 'config_completion_email_body',
                // NUEVO: Mapeo para BBB
                'enable_bbb_reminder_email' => 'config_enable_bbb_reminder_email',
                'bbb_reminder_email_subject' => 'config_bbb_reminder_email_subject',
                'bbb_reminder_email_body' => 'config_bbb_reminder_email_body',
            ];
    
            foreach ($fieldmap as $configkey => $formfield) {
                if (property_exists($configdata, $configkey)) {
                    $value = $configdata->$configkey;
                    // Manejo especial para campos de editor
                    if (in_array($configkey, ['start_email_body', 'progress20_email_body', 'completion_email_body', 'bbb_reminder_email_body'])) { // AÑADIDO 'bbb_reminder_email_body'
                        if (is_string($value)) {
                            $defaults->$formfield = ['text' => $value, 'format' => FORMAT_HTML];
                        } else if (is_array($value) && isset($value['text'])) { // Ya debería ser string por instance_config_save
                            $defaults->$formfield = $value;
                        } else if (is_object($value) && isset($value->text)) { // Ya debería ser string
                            $defaults->$formfield = (array)$value;
                        } else {
                             // Si el valor guardado es null o inesperado después de instance_config_save
                             $default_string_key = 'default' . str_replace('_', '', $configkey); // ej. defaultstartemailbody
                             $defaults->$formfield = ['text' => get_string($default_string_key, 'block_course_notifications'), 'format' => FORMAT_HTML];
                        }
                    } else {
                        $defaults->$formfield = $value;
                    }
                }
            }
        }
        parent::set_data($defaults);
    }
}