<?php
defined('MOODLE_INTERNAL') || die();

$tasks = [
    [
        'classname' => '\block_course_notifications\task\send_start_emails',
        'blocking'  => 0,
        'minute'    => '*/5', // Temporalmente cada 5 minutos para pruebas
        'hour'      => '*',
        'day'       => '*',
        'month'     => '*',
        'dayofweek' => '*',
    ],
];
