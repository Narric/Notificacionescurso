<?php
defined('MOODLE_INTERNAL') || die();

$tasks = [
    [
        'classname' => '\block_course_notifications\task\send_start_emails',
        'blocking'  => 0,
        'minute'    => '*/5', // Cada 5 minutos
        'hour'      => '*',
        'day'       => '*',
        'month'     => '*',
        'dayofweek' => '*',
    ],
    [
        'classname' => '\block_course_notifications\task\send_progress20_emails',
        'blocking'  => 0,
        'minute'    => '30',    // A los 30 minutos de la hora
        'hour'      => '2',     // A las 2:30 AM
        'day'       => '*',
        'month'     => '*',
        'dayofweek' => '*',
    ],
    [
        'classname' => '\block_course_notifications\task\send_completion_emails',
        'blocking'  => 0,
        'minute'    => '15',    // A los 15 minutos de la hora
        'hour'      => '3',     // A las 3:15 AM
        'day'       => '*',
        'month'     => '*',
        'dayofweek' => '*',
    ],
    // NUEVA TAREA
    [
        'classname' => '\block_course_notifications\task\send_bbb_reminder_emails',
        'blocking'  => 0,
        'minute'    => '5',     // A los 5 minutos de la hora
        'hour'      => '0',     // A las 00:05 AM (o la hora que prefieras para recordatorios del mismo día)
        'day'       => '*',
        'month'     => '*',
        'dayofweek' => '*',
    ],
];