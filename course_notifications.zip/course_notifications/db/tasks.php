<?php
defined('MOODLE_INTERNAL') || die();

$tasks = [
    [
        'classname' => '\block_course_notifications\task\send_start_emails',
        'blocking'  => 0,
        'minute'    => '*/5',
        'hour'      => '*',
        'day'       => '*',
        'month'     => '*',
        'dayofweek' => '*',
    ],
    [
        'classname' => '\block_course_notifications\task\send_progress20_emails', // CAMBIADO si renombraste la clase
        'blocking'  => 0,
        'minute'    => '30',
        'hour'      => '2',
        'day'       => '*',
        'month'     => '*',
        'dayofweek' => '*',
    ],
    [
        'classname' => '\block_course_notifications\task\send_completion_emails',
        'blocking'  => 0,
        'minute'    => '15',    // A los 15 minutos de la hora
        'hour'      => '3',     // A las 3:15 AM (o la hora que prefieras, distinta a las otras)
        'day'       => '*',
        'month'     => '*',
        'dayofweek' => '*',
    ],
    [
        'classname' => '\block_course_notifications\task\send_bbb_reminder_emails',
        'blocking'  => 0,
        'minute'    => '0',    // En el minuto 0
        'hour'      => '7',    // A las 7 AM (hora del servidor)
        'day'       => '*',
        'month'     => '*',
        'dayofweek' => '*',
    ],
];