<?php
defined('MOODLE_INTERNAL') || die();

$capabilities = array(

    // Capacidad para añadir el bloque a la página "Mi vista general" (My home)
    'block/course_notifications:myaddinstance' => array(
        'captype' => 'write',
        'contextlevel' => CONTEXT_SYSTEM, // Se comprueba a nivel de sistema, pero se aplica al contexto del usuario.
        'archetypes' => array(
            'user' => CAP_ALLOW // Por defecto, los usuarios autenticados pueden añadirlo a su "Mi vista general".
        ),
        'clonepermissionsfrom' => 'moodle/my:manageblocks'
    ),

    // Capacidad para añadir el bloque a páginas de curso y otras páginas.
    'block/course_notifications:addinstance' => array(
        'riskbitmask' => RISK_SPAM | RISK_XSS, // Riesgos potenciales si se permite a roles no confiables.
        'captype' => 'write',
        'contextlevel' => CONTEXT_BLOCK, // Se aplica al contexto donde se añade el bloque (ej. curso).
        'archetypes' => array(
            'editingteacher' => CAP_ALLOW, // Profesores con permiso de edición pueden añadirlo.
            'manager' => CAP_ALLOW        // Gestores pueden añadirlo.
        ),
        'clonepermissionsfrom' => 'moodle/site:manageblocks' // Hereda permisos de una capacidad central.
    ),

    // Podrías añadir una capacidad 'block/course_notifications:view' si necesitas un control
    // más fino sobre quién puede ver el bloque, pero normalmente no es necesario
    // ya que la visibilidad del bloque se controla por otros medios (contexto, permisos de curso).
);