<?php
defined('MOODLE_INTERNAL') || die();

function xmldb_block_course_notifications_upgrade($oldversion) {
    global $DB;
    $dbman = $DB->get_manager();

    // ... (tus bloques de versiones anteriores: 2024031700, 2024031800, 2025052600) ...
    // Mantén tus bloques de versiones anteriores tal como los tienes, por si alguien actualiza desde una versión muy vieja.

    // Bloque para asegurar que cmid y el índice correcto existen para la versión 2025052800
    // Si la versión en la BD es < 2025052800, este bloque se ejecutará.
    if ($oldversion < 2025052800) {
        mtrace("Running upgrade step for version 2025052800: Ensure cmid field and new index for block_cn_progress_reminders.");
        $table = new xmldb_table('block_cn_progress_reminders');

        // 1. Añadir el campo 'cmid' si no existe
        $field_cmid = new xmldb_field('cmid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, false, '0', 'userid');
        if (!$dbman->field_exists($table, $field_cmid)) {
            mtrace("Attempting to add field 'cmid' to table 'block_cn_progress_reminders'.");
            $dbman->add_field($table, $field_cmid);
            mtrace("SUCCESS: Added field 'cmid'.");
        } else {
            mtrace("NOTICE: Field 'cmid' already exists.");
        }

        // 2. Eliminar el índice antiguo si existe.
        $oldindexname = 'courseuserremtype_uk'; // El que probablemente existía
        if ($dbman->index_exists($table, $oldindexname)) {
            $index_to_drop = new xmldb_index($oldindexname);
            mtrace("Attempting to drop old index: " . $oldindexname);
            $dbman->drop_index($table, $index_to_drop);
            mtrace("SUCCESS: Dropped old index: " . $oldindexname);
        } else {
            mtrace("NOTICE: Old unique index '{$oldindexname}' not found or already dropped.");
        }

        // 3. Añadir el nuevo índice único incluyendo cmid
        $newindex = new xmldb_index('courseuserremtypecm_uk', XMLDB_INDEX_UNIQUE, array('courseid', 'userid', 'reminder_type', 'cmid'));
        if (!$dbman->index_exists($table, $newindex)) {
            mtrace("Attempting to add new unique index: 'courseuserremtypecm_uk'.");
            $dbman->add_index($table, $newindex);
            mtrace("SUCCESS: Added new unique index 'courseuserremtypecm_uk'.");
        } else {
            mtrace("NOTICE: New unique index 'courseuserremtypecm_uk' already exists.");
        }
        upgrade_plugin_savepoint(true, 2025052800, 'block', 'course_notifications');
        mtrace("Upgrade to version 2025052800 for cmid addition completed.");
    }


    // --- NUEVO BLOQUE DE VERSIÓN DE "CORRECCIÓN" ---
    // Este bloque se ejecutará si la versión en la BD es < 2026061899 (tu versión actual en version.php)
    // Se asegura de que los cambios de la versión 2025052800 (cmid y el índice) estén aplicados,
    // por si acaso fallaron o no se ejecutaron correctamente antes, y la versión en BD ya superó 2025052800.
    if ($oldversion < 2026061899) { // USA TU VERSIÓN ACTUAL DE version.php
        mtrace("Running corrective upgrade step for version 2026061899: Double-checking cmid field and new index for block_cn_progress_reminders.");
        
        $table = new xmldb_table('block_cn_progress_reminders');

        // Asegurar que la tabla 'block_cn_progress_reminders' exista (por si acaso)
        // Aunque debería haber sido creada por la versión 2025052600 o install.xml
        if (!$dbman->table_exists($table)) {
            mtrace("CRITICAL ERROR: Table 'block_cn_progress_reminders' does not exist. Cannot apply cmid fix. Please check previous upgrade steps or install.xml.");
            // No se puede continuar si la tabla no existe.
        } else {
            // 1. RE-VERIFICAR Y AÑADIR el campo 'cmid' si aún no existe
            $field_cmid_check = new xmldb_field('cmid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, false, '0', 'userid');
            if (!$dbman->field_exists($table, $field_cmid_check)) {
                mtrace("Corrective action: Field 'cmid' is MISSING. Attempting to add it now.");
                $dbman->add_field($table, $field_cmid_check);
                mtrace("SUCCESS: Corrective action - Added field 'cmid'.");
            } else {
                mtrace("Corrective check: Field 'cmid' already exists.");
            }

            // 2. RE-VERIFICAR Y AJUSTAR ÍNDICES
            $oldindexname_check = 'courseuserremtype_uk';
            $newindex_check = new xmldb_index('courseuserremtypecm_uk', XMLDB_INDEX_UNIQUE, array('courseid', 'userid', 'reminder_type', 'cmid'));

            // Si el nuevo índice no existe, intentamos crearlo.
            // Esto implica que si el antiguo existe, debería ser eliminado primero si entra en conflicto.
            if (!$dbman->index_exists($table, $newindex_check)) {
                // Intentar eliminar el antiguo índice si aún existe, ANTES de crear el nuevo.
                if ($dbman->index_exists($table, $oldindexname_check)) {
                    $index_to_drop_check = new xmldb_index($oldindexname_check);
                    mtrace("Corrective action: Old index '{$oldindexname_check}' found. Attempting to drop it.");
                    $dbman->drop_index($table, $index_to_drop_check);
                    mtrace("SUCCESS: Corrective action - Dropped old index: "{$oldindexname_check}'.');
                }
                mtrace("Corrective action: New index 'courseuserremtypecm_uk' is MISSING. Attempting to add it now.");
                $dbman->add_index($table, $newindex_check);
                mtrace("SUCCESS: Corrective action - Added new unique index 'courseuserremtypecm_uk'.");
            } else {
                mtrace("Corrective check: New unique index 'courseuserremtypecm_uk' already exists.");
                // Si el nuevo índice ya existe, asegurarnos que el antiguo no exista (por si acaso)
                if ($dbman->index_exists($table, $oldindexname_check)) {
                    // Esto podría indicar un problema si ambos existen y tienen campos en común que causen conflicto,
                    // pero el nuevo índice es el que queremos.
                    mtrace("WARNING: New index 'courseuserremtypecm_uk' exists, but old index '{$oldindexname_check}' also found. This might be okay or might need manual DB check if there were errors previously.");
                }
            }
        }
        upgrade_plugin_savepoint(true, 2026061899, 'block', 'course_notifications'); // USA TU VERSIÓN ACTUAL
        mtrace("Corrective upgrade to version 2026061899 for block_course_notifications completed.");
    }

    return true;
}