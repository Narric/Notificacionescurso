<?php
defined('MOODLE_INTERNAL') || die();

/**
 * Función de actualización para el plugin block_course_notifications.
 *
 * Esta función se llama cuando la versión del plugin en la base de datos
 * es más antigua que la versión definida en version.php. Moodle compara
 * $oldversion (la versión actualmente registrada en la BD para este plugin)
 * con la $plugin->version de version.php. Si $oldversion es menor, se ejecuta
 * esta función, pasando la $oldversion actual.
 *
 * @param int $oldversion La versión antigua del plugin que está instalada.
 *                        Si es la primera instalación con BD, Moodle podría llamar
 *                        a esto con $oldversion = 0 o un valor muy bajo si antes
 *                        no había registro de versión para este plugin.
 *                        `install.xml` se usa para la creación inicial de tablas.
 *                        Este `upgrade.php` es para modificaciones *posteriores* a esas tablas
 *                        o para añadir nuevas tablas en versiones subsiguientes.
 * @return bool true si la actualización fue exitosa, false en caso contrario.
 */
function xmldb_block_course_notifications_upgrade($oldversion) {
    global $DB; // Acceso global a la base de datos de Moodle.

    // El DDL (Data Definition Language) manager es necesario para hacer cambios
    // en la estructura de la base de datos (crear/modificar tablas, campos, etc.).
    $dbman = $DB->get_manager();

    // -----------------------------------------------------------------------------------
    // Ejemplo 1: Añadir un nuevo campo a la tabla 'block_cn_initial_sents'
    // Supongamos que en una futura versión (2024031700) decidimos añadir un campo
    // para contar los intentos de reenvío.
    // -----------------------------------------------------------------------------------
    if ($oldversion < 2024031700) { // Este número es un ejemplo de una futura versión.

        // 1. Definir la tabla que se va a modificar.
        $table = new xmldb_table('block_cn_initial_sents');

        // 2. Definir el nuevo campo 'retry_attempts'.
        // XMLDB_TYPE_INTEGER: Tipo de dato entero.
        // '3': Longitud (opcional para algunos tipos, pero bueno especificar).
        // null: No es unsigned.
        // XMLDB_NOTNULL: El campo no puede ser nulo.
        // true: Es un campo con secuencia (autoincremental) -> false en este caso.
        // '0': Valor por defecto.
        // 'status': Campo después del cual se añadirá este nuevo campo (opcional, para orden).
        $field = new xmldb_field('retry_attempts', XMLDB_TYPE_INTEGER, '3', null, XMLDB_NOTNULL, false, '0', 'status');

        // 3. Comprobar si el campo ya existe (importante para evitar errores si el script se ejecuta múltiples veces).
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field); // Añadir el campo a la tabla.
        }

        // 4. Guardar un punto de control de la actualización.
        // Esto actualiza la versión del plugin en la base de datos a 2024031700
        // para que este bloque de código no se ejecute de nuevo en futuras actualizaciones.
        upgrade_plugin_savepoint(true, 2024031700, 'block', 'course_notifications');
    }

    // -----------------------------------------------------------------------------------
    // Ejemplo 2: Añadir una nueva tabla para registrar recordatorios de tareas
    // Supongamos que en una versión aún más futura (2024031800) añadimos la funcionalidad
    // de enviar recordatorios para tareas.
    // -----------------------------------------------------------------------------------
    if ($oldversion < 2024031800) { // Ejemplo de otra futura versión.

        // 1. Definir la nueva tabla 'block_cn_task_reminders'.
        $table = new xmldb_table('block_cn_task_reminders');

        // 2. Añadir campos a la nueva tabla.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, true, null, null); // Clave primaria.
        $table->add_field('coursemoduleid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, false, null, null); // ID de la instancia de módulo (ej. tarea).
        $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, false, null, null);
        $table->add_field('timesent', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, false, '0', null);
        $table->add_field('reminder_type', XMLDB_TYPE_CHAR, '50', null, XMLDB_NOTNULL, false, '', null); // Ej. 'due_soon', 'overdue'

        // 3. Definir la clave primaria.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));

        // 4. Definir claves foráneas (ejemplo).
        $table->add_key('cmid_fk', XMLDB_KEY_FOREIGN, array('coursemoduleid'), 'course_modules', array('id'));
        $table->add_key('userid_rem_fk', XMLDB_KEY_FOREIGN, array('userid'), 'user', array('id'));

        // 5. Definir índices (ejemplo).
        $table->add_index('cmid_user_uk', XMLDB_INDEX_UNIQUE, array('coursemoduleid', 'userid', 'reminder_type'));

        // 6. Comprobar si la tabla ya existe antes de crearla.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table); // Crear la tabla.
        }

        // 7. Guardar un punto de control de la actualización.
        upgrade_plugin_savepoint(true, 2024031800, 'block', 'course_notifications');
    }

    // Siempre devuelve true si todos los pasos de actualización (si los hubo para esta $oldversion)
    // se completaron o si no había nada que actualizar para la $oldversion dada.
    return true;
}