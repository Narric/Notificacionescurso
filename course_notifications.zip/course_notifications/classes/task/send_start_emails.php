<?php
// Define el namespace para esta clase, crucial para el autocargador de Moodle.
namespace block_course_notifications\task;

// Asegura que el script no se ejecute fuera del entorno de Moodle.
defined('MOODLE_INTERNAL') || die();

// Incluye archivos de la librería de Moodle que contienen funciones globales necesarias.
require_once($CFG->libdir.'/moodlelib.php');
require_once($CFG->libdir.'/messagelib.php');

/**
 * Tarea programada para enviar correos de notificación al inicio del curso.
 * Lógica modificada: envía si el curso ha comenzado y el correo no se ha enviado previamente al usuario.
 */
class send_start_emails extends \core\task\scheduled_task {

    /**
     * Devuelve el nombre legible por humanos de la tarea.
     *
     * @return string El nombre localizado de la tarea.
     */
    public function get_name() {
        return get_string('send_start_emails_task', 'block_course_notifications');
    }

    /**
     * El método principal que se ejecuta cuando el sistema cron de Moodle llama a esta tarea.
     */
    public function execute() {
        global $DB, $CFG;

        mtrace("Cron task 'send_start_emails' (logic: send if course started & not yet sent) from block_course_notifications started.");

        $current_time_utc = time();
        mtrace("Current time for comparison (UTC timestamp): " . $current_time_utc . " (" . gmdate('Y-m-d H:i:s', $current_time_utc) . " UTC)");

        $block_instances = $DB->get_records_sql(
            "SELECT bi.*, c.id AS courseid, c.fullname AS coursename, c.startdate AS coursestartdate
             FROM {block_instances} bi
             JOIN {context} ctx ON bi.parentcontextid = ctx.id
             JOIN {course} c ON ctx.instanceid = c.id
             WHERE bi.blockname = :blockname AND ctx.contextlevel = :contextlevel",
            ['blockname' => 'course_notifications', 'contextlevel' => CONTEXT_COURSE]
        );

        if (empty($block_instances)) {
            mtrace("No instances of block_course_notifications found in course contexts. Task finished.");
            return;
        }

        mtrace(count($block_instances) . " block instances found in course contexts.");

        foreach ($block_instances as $bi) {
            mtrace("Processing block instance ID: {$bi->id} for course ID: {$bi->courseid} ('{$bi->coursename}')");

            if (empty($bi->coursestartdate)) {
                 mtrace("Course ID {$bi->courseid} ('{$bi->coursename}') has no startdate defined. Skipping.");
                 continue;
            }
            mtrace("Course startdate from DB: {$bi->coursestartdate} (" . gmdate('Y-m-d H:i:s', $bi->coursestartdate) . " UTC)");

            if ($bi->coursestartdate <= $current_time_utc) {
                mtrace("Course ID {$bi->courseid} ('{$bi->coursename}') has started (or is starting now). Checking block configuration.");

                $config = new \stdClass();
                if (!empty($bi->configdata)) {
                    $decoded_config = unserialize(base64_decode($bi->configdata));
                    if (is_object($decoded_config)) {
                        $config = $decoded_config;
                    } else if (is_array($decoded_config)) {
                        $config = (object)$decoded_config;
                    }
                }

                if (!empty($config->enable_start_email)) {
                    mtrace("Course start email ENABLED for course ID: {$bi->courseid}. Fetching enrolled users.");

                    $coursecontext = \context_course::instance($bi->courseid);
                    $enrolled_users = get_enrolled_users(
                        $coursecontext, '', 0,
                        'u.id, u.username, u.firstname, u.lastname, u.email, u.mnethostid, u.suspended, u.deleted, u.confirmed, u.auth'
                    );

                    if (empty($enrolled_users)) {
                        mtrace("No users found for course ID: {$bi->courseid} after get_enrolled_users call.");
                        continue;
                    }

                    mtrace(count($enrolled_users) . " users initially fetched for course ID: {$bi->courseid}. Filtering and processing...");

                    $emailsubject_template = !empty($config->start_email_subject) ? $config->start_email_subject : get_string('defaultstartemailsubject', 'block_course_notifications');
                    
                    // ---- INICIO DE LA CORRECCIÓN PARA EL CUERPO DEL EMAIL ----
                    // Obtener la plantilla del cuerpo del correo desde la configuración.
                    $raw_email_body_template = !empty($config->start_email_body) ? $config->start_email_body : get_string('defaultstartemailbody', 'block_course_notifications');
                    $emailbody_html_template = ''; // Inicializar como cadena vacía

                    // Asegurarse de que $emailbody_html_template es una cadena de texto HTML.
                    if (is_array($raw_email_body_template) && isset($raw_email_body_template['text'])) {
                        // Si es un array del editor (ej. ['text' => '...', 'format' => ...]), tomar solo el texto.
                        $emailbody_html_template = $raw_email_body_template['text'];
                        mtrace("Extracted 'text' from array for email body template for course ID: {$bi->courseid}.");
                    } else if (is_string($raw_email_body_template)) {
                        // Si ya es una cadena (porque instance_config_save guardó solo el texto).
                        $emailbody_html_template = $raw_email_body_template;
                        mtrace("Email body template is already a string for course ID: {$bi->courseid}.");
                    } else {
                        // Fallback si es algo inesperado (ej. null, objeto sin 'text'), usar el string por defecto.
                        mtrace("Email body template for course ID {$bi->courseid} has unexpected format or is empty, using default string.");
                        $emailbody_html_template = get_string('defaultstartemailbody', 'block_course_notifications');
                    }
                    // ---- FIN DE LA CORRECCIÓN PARA EL CUERPO DEL EMAIL ----
                                        
                    $course_url_obj = new \moodle_url('/course/view.php', ['id' => $bi->courseid]);
                    $course_link = $course_url_obj->out(false);

                    $supportuser = \core_user::get_support_user();
                    if (!$supportuser) {
                        $supportuser = \core_user::get_noreply_user();
                    }

                    foreach ($enrolled_users as $user) {
                        if (!empty($user->suspended) || !empty($user->deleted) || empty($user->confirmed) || $user->auth === 'nologin' || empty($user->email)) {
                            mtrace("Skipping user: {$user->username} (ID: {$user->id}) for course {$bi->courseid}. Reason: " .
                                   "suspended=" . (!empty($user->suspended)?'yes':'no') .
                                   ", deleted=" . (!empty($user->deleted)?'yes':'no') .
                                   ", confirmed=" . (!empty($user->confirmed)?'yes':'no') .
                                   ", auth={$user->auth}" .
                                   ", email_empty=" . (empty($user->email) ? 'yes':'no'));
                            continue;
                        }

                        $already_sent = $DB->get_record('block_cn_initial_sents', ['courseid' => $bi->courseid, 'userid' => $user->id]);
                        if ($already_sent) {
                            mtrace("Initial email ALREADY LOGGED for user {$user->username} (ID: {$user->id}), course {$bi->courseid}. Status: {$already_sent->status}. Skipping.");
                            continue;
                        }

                        mtrace("Preparing to send course start email to user: {$user->username} (ID: {$user->id}, Email: {$user->email}) for course {$bi->courseid}");

                        $messagevars = [
                            '{coursename}'       => $bi->coursename,
                            '{studentfirstname}' => $user->firstname,
                            '{studentlastname}'  => $user->lastname,
                            '{courselink}'       => $course_link,
                        ];

                        $subject_processed = str_replace(array_keys($messagevars), array_values($messagevars), $emailsubject_template);
                        // Ahora $emailbody_html_template es garantizado (o se espera que sea) una cadena.
                        $body_html_processed = str_replace(array_keys($messagevars), array_values($messagevars), $emailbody_html_template);
                        $body_plain_processed = html_to_text($body_html_processed);

                        $email_status = 'failed';
                        $email_sent_successfully = false;

                        try {
                            $email_sent_successfully = email_to_user(
                                $user, $supportuser, $subject_processed,
                                $body_plain_processed, $body_html_processed
                            );

                            if ($email_sent_successfully) {
                                mtrace("Email successfully sent to {$user->username} (ID: {$user->id}) for course {$bi->courseid}.");
                                $email_status = 'sent';
                            } else {
                                mtrace("ERROR: email_to_user reported failure for user {$user->username} (ID: {$user->id}), course {$bi->courseid}.");
                            }
                        } catch (\Exception $e) {
                             mtrace("EXCEPTION during email_to_user for user {$user->username} (ID: {$user->id}), course {$bi->courseid}: " . $e->getMessage());
                        }

                        $log_record = new \stdClass();
                        $log_record->courseid = $bi->courseid;
                        $log_record->userid = $user->id;
                        $log_record->timesent = time();
                        $log_record->status = $email_status;
                        
                        try {
                            $DB->insert_record('block_cn_initial_sents', $log_record, false);
                            mtrace("Logged email attempt (status: {$email_status}) for user {$user->id}, course {$bi->courseid}. This email will not be sent again to this user for this course.");
                        } catch (\dml_exception $e) {
                            mtrace("ERROR: Could not insert log record for user {$user->id}, course {$bi->courseid}. DML Exception: " . $e->getMessage());
                        }
                    }

                } else {
                    mtrace("Course start email DISABLED for block instance in course ID: {$bi->courseid}.");
                }
            } else {
                 mtrace("Course ID {$bi->courseid} ('{$bi->coursename}') has not started yet (startdate: " . gmdate('Y-m-d H:i:s', $bi->coursestartdate) . " UTC > current_time: " . gmdate('Y-m-d H:i:s', $current_time_utc) . " UTC). Skipping.");
            }
        }

        mtrace("Cron task 'send_start_emails' (logic: send if course started & not yet sent) from block_course_notifications finished.");
    }
}