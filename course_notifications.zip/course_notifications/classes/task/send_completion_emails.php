<?php
namespace block_course_notifications\task;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir.'/moodlelib.php');
require_once($CFG->libdir.'/messagelib.php');
require_once($CFG->libdir.'/modinfolib.php'); // Para get_fast_modinfo

class send_completion_emails extends \core\task\scheduled_task {

    public function get_name() {
        return get_string('send_completion_emails_task', 'block_course_notifications');
    }

    public function execute() {
        global $DB, $CFG;

        mtrace("Cron task 'send_completion_emails' (Direct DB Quiz Check - Full DB Mode) from block_course_notifications started.");
        $currenttime = time();

        $block_instances = $DB->get_records_sql(
            "SELECT bi.id AS bi_id, bi.configdata, bi.parentcontextid,
                    c.id AS courseid, c.fullname AS coursename, c.startdate AS coursestartdate
             FROM {block_instances} bi
             JOIN {context} ctx ON bi.parentcontextid = ctx.id
             JOIN {course} c ON ctx.instanceid = c.id
             WHERE bi.blockname = :blockname AND ctx.contextlevel = :contextlevel",
            ['blockname' => 'course_notifications', 'contextlevel' => CONTEXT_COURSE]
        );

        if (empty($block_instances)) {
            mtrace("No instances of block_course_notifications found. Task finished.");
            return;
        }

        foreach ($block_instances as $bi) {
            mtrace("Processing block instance ID: {$bi->bi_id} for course ID: {$bi->courseid} ('{$bi->coursename}')");

            $config = new \stdClass();
            if (!empty($bi->configdata)) {
                $decoded_config = unserialize(base64_decode($bi->configdata));
                $config = is_object($decoded_config) ? $decoded_config : (object)$decoded_config;
            }

            if (empty($config->enable_completion_email)) {
                mtrace("Quiz-based (Full DB Mode) completion email DISABLED for course ID: {$bi->courseid}. Skipping.");
                continue;
            }
            mtrace("Quiz-based (Full DB Mode) completion email ENABLED for course ID: {$bi->courseid}.");
            
            if (empty($bi->coursestartdate) || $bi->coursestartdate > $currenttime) {
                mtrace("Course ID {$bi->courseid} has not started yet or has no start date. Skipping.");
                continue;
            }

            $modinfo = get_fast_modinfo($bi->courseid);
            $course_quizzes_data = []; 
            foreach ($modinfo->get_cms() as $cm) {
                if ($cm->modname == 'quiz' && $cm->uservisible) {
                    $quiz_instance_record = $DB->get_record('quiz', ['id' => $cm->instance]);
                    if ($quiz_instance_record) {
                        $course_quizzes_data[$cm->id] = ['cm_info' => $cm, 'quiz_record' => $quiz_instance_record];
                    }
                }
            }

            if (empty($course_quizzes_data)) {
                mtrace("No visible quizzes with valid quiz records found in course ID: {$bi->courseid}. Skipping this course.");
                continue;
            }
            mtrace(count($course_quizzes_data) . " visible quizzes found in course ID: {$bi->courseid}.");

            $coursecontext = \context_course::instance($bi->courseid);
            $enrolled_users = get_enrolled_users(
                $coursecontext, '', 0,
                'u.id, u.username, u.firstname, u.lastname, u.email, u.mnethostid, u.suspended, u.deleted, u.confirmed, u.auth'
            );

            if (empty($enrolled_users)) {
                mtrace("No users found for course ID: {$bi->courseid}.");
                continue;
            }

            $emailsubject_template = !empty($config->completion_email_subject) ? $config->completion_email_subject : get_string('defaultcompletionsubject', 'block_course_notifications');
            $raw_email_body_template = !empty($config->completion_email_body) ? $config->completion_email_body : get_string('defaultcompletionbody', 'block_course_notifications');
            $emailbody_html_template = is_array($raw_email_body_template) && isset($raw_email_body_template['text']) ? $raw_email_body_template['text'] : (is_string($raw_email_body_template) ? $raw_email_body_template : get_string('defaultcompletionbody', 'block_course_notifications'));

            $course_url_obj = new \moodle_url('/course/view.php', ['id' => $bi->courseid]);
            $course_link = $course_url_obj->out(false);
            $supportuser = \core_user::get_support_user() ?: \core_user::get_noreply_user();

            foreach ($enrolled_users as $user) {
                if (!empty($user->suspended) || !empty($user->deleted) || empty($user->confirmed) || $user->auth === 'nologin' || empty($user->email)) {
                    mtrace("Skipping user (basic check): {$user->username} (ID: {$user->id}) for course {$bi->courseid}.");
                    continue;
                }

                // CORRECCIÓN 3: Acortar el tipo de recordatorio
                $reminder_type_for_log = 'quiz_all_db'; 
                $already_sent = $DB->get_record('block_cn_progress_reminders', [
                    'courseid'      => $bi->courseid,
                    'userid'        => $user->id,
                    'reminder_type' => $reminder_type_for_log 
                ]);

                if ($already_sent) {
                    mtrace("Quiz-based (Full DB Mode) completion email ALREADY LOGGED (type: {$reminder_type_for_log}) for user {$user->username} (ID: {$user->id}), course {$bi->courseid}. Skipping.");
                    continue;
                }

                $all_quizzes_considered_complete = true;
                $latest_quiz_attempt_finish_time = 0;

                foreach ($course_quizzes_data as $cmid => $quiz_data) {
                    $quiz_cm_info = $quiz_data['cm_info'];
                    $quiz_record = $quiz_data['quiz_record'];

                    mtrace("Checking quiz '{$quiz_record->name}' (QuizID: {$quiz_record->id}, CMID: {$cmid}) for user {$user->username} (ID: {$user->id})");

                    $attempts = $DB->get_records('quiz_attempts', [
                        'quiz' => $quiz_record->id, 
                        'userid' => $user->id, 
                        'state' => 'finished'
                    ], 'timefinish DESC');

                    if (empty($attempts)) {
                        mtrace("User {$user->username} has NO finished attempts for quiz '{$quiz_record->name}'. Marking as not complete for email.");
                        $all_quizzes_considered_complete = false;
                        break; 
                    }

                    $quiz_passed_or_criteria_met = false;
                    $current_quiz_latest_finish_time_for_user = 0;

                    if (isset($quiz_record->gradepass) && $quiz_record->gradepass > 0) {
                        foreach ($attempts as $attempt) {
                            if ($attempt->sumgrades !== null && $attempt->sumgrades >= $quiz_record->gradepass) {
                                $quiz_passed_or_criteria_met = true;
                                $current_quiz_latest_finish_time_for_user = $attempt->timefinish;
                                break; 
                            }
                        }
                        if (!$quiz_passed_or_criteria_met) {
                            mtrace("User {$user->username} has finished attempts for quiz '{$quiz_record->name}', but NONE meet gradepass ({$quiz_record->gradepass}). Marking as not complete for email.");
                            $all_quizzes_considered_complete = false;
                            break;
                        }
                         mtrace("User {$user->username} PASSED quiz '{$quiz_record->name}' (gradepass: {$quiz_record->gradepass}). Latest passing attempt time: " . userdate($current_quiz_latest_finish_time_for_user));
                    } else {
                        $first_attempt = reset($attempts); 
                        $current_quiz_latest_finish_time_for_user = $first_attempt->timefinish;
                        $quiz_passed_or_criteria_met = true;
                        mtrace("User {$user->username} FINISHED quiz '{$quiz_record->name}' (no gradepass). Latest attempt time: " . userdate($current_quiz_latest_finish_time_for_user));
                    }
                    
                    if ($quiz_passed_or_criteria_met && $current_quiz_latest_finish_time_for_user > $latest_quiz_attempt_finish_time) {
                        $latest_quiz_attempt_finish_time = $current_quiz_latest_finish_time_for_user;
                    }
                } 

                if ($all_quizzes_considered_complete && !empty($course_quizzes_data) && $latest_quiz_attempt_finish_time > 0) {
                    mtrace("User {$user->username} (ID: {$user->id}) has COMPLETED ALL VISIBLE QUIZZES (Full DB Mode) for course {$bi->courseid}. Latest quiz finish time: " . userdate($latest_quiz_attempt_finish_time) . ". Preparing email.");

                    // CORRECCIÓN 1: Formato de fecha
                    $completiondate_formatted = userdate($latest_quiz_attempt_finish_time); 

                    $messagevars = [
                        '{coursename}'       => $bi->coursename,
                        '{studentfirstname}' => $user->firstname,
                        '{studentlastname}'  => $user->lastname,
                        '{courselink}'       => $course_link,
                        '{completiondate}'   => $completiondate_formatted,
                    ];

                    $subject_processed = str_replace(array_keys($messagevars), array_values($messagevars), $emailsubject_template);
                    $body_html_processed = str_replace(array_keys($messagevars), array_values($messagevars), $emailbody_html_template);
                    $body_plain_processed = html_to_text($body_html_processed);

                    $email_status = 'failed';
                    try {
                        if (email_to_user($user, $supportuser, $subject_processed, $body_plain_processed, $body_html_processed)) {
                            mtrace("Quiz-based (Full DB Mode) completion email successfully sent to {$user->username} (ID: {$user->id}) for course {$bi->courseid}.");
                            $email_status = 'sent';
                        } else {
                            mtrace("ERROR: Quiz-based (Full DB Mode) completion email_to_user reported failure for user {$user->username} (ID: {$user->id}), course {$bi->courseid}.");
                        }
                    } catch (\Exception $e) {
                        mtrace("EXCEPTION during quiz-based (Full DB Mode) completion email_to_user for user {$user->username} (ID: {$user->id}), course {$bi->courseid}: " . $e->getMessage());
                    }

                    $log_record = new \stdClass();
                    $log_record->courseid = $bi->courseid;
                    $log_record->userid = $user->id;
                    $log_record->timesent = $currenttime;
                    $log_record->status = $email_status;
                    $log_record->reminder_type = $reminder_type_for_log; 
                    
                    try {
                        $DB->insert_record('block_cn_progress_reminders', $log_record, false);
                        mtrace("Logged quiz-based (Full DB Mode) completion email attempt (status: {$email_status}, type: {$reminder_type_for_log}) for user {$user->id}, course {$bi->courseid}.");
                    } catch (\dml_exception $e) {
                        mtrace("ERROR: Could not insert quiz-based (Full DB Mode) completion log record (type: {$reminder_type_for_log}) for user {$user->id}, course {$bi->courseid}. DML Exception: " . $e->getMessage());
                    }
                } else if ($all_quizzes_considered_complete && !empty($course_quizzes_data) && $latest_quiz_attempt_finish_time == 0){
                     mtrace("User {$user->username} (ID: {$user->id}) met quiz completion criteria for course {$bi->courseid} (Full DB Mode), but no latest_quiz_attempt_finish_time was derived. Skipping email.");
                }
            } 
        } 
        mtrace("Cron task 'send_completion_emails' (Full DB Mode) from block_course_notifications finished.");
    }
}