<?php
namespace block_course_notifications\task;

defined('MOODLE_INTERNAL') || die();

// Incluye archivos de la librería de Moodle.
require_once($CFG->libdir.'/moodlelib.php');
require_once($CFG->libdir.'/messagelib.php');
// Podrías necesitar incluir course/lib.php si usas funciones específicas de curso
// require_once($CFG->dirroot.'/course/lib.php');

class send_progress20_emails extends \core\task\scheduled_task { // NOMBRE DE CLASE CAMBIADO

    /**
     * Devuelve el nombre legible por humanos de la tarea.
     * @return string
     */
    public function get_name() {
        return get_string('send_progress20_emails_task', 'block_course_notifications'); // CLAVE DE STRING CAMBIADA
    }

    /**
     * El método principal que se ejecuta cuando el cron llama a esta tarea.
     */
    public function execute() {
        global $DB, $CFG;

        mtrace("Cron task 'send_progress20_emails' from block_course_notifications started."); // MENSAJE CAMBIADO
        $current_time_utc = time();

        // 1. Obtener instancias del bloque con la configuración relevante.
        $block_instances = $DB->get_records_sql(
            "SELECT bi.id AS bi_id, bi.configdata, bi.parentcontextid, 
                    c.id AS courseid, c.fullname AS coursename, c.shortname AS courseshortname, 
                    c.startdate AS coursestartdate, c.enddate AS courseenddate
             FROM {block_instances} bi
             JOIN {context} ctx ON bi.parentcontextid = ctx.id
             JOIN {course} c ON ctx.instanceid = c.id
             WHERE bi.blockname = :blockname AND ctx.contextlevel = :contextlevel",
            ['blockname' => 'course_notifications', 'contextlevel' => CONTEXT_COURSE]
        );

        if (empty($block_instances)) {
            mtrace("No instances of block_course_notifications found in course contexts. Task finished.");
            return;
        }

        mtrace(count($block_instances) . " block instances found in course contexts.");

        foreach ($block_instances as $bi) {
            mtrace("Processing block instance ID: {$bi->bi_id} for course ID: {$bi->courseid} ('{$bi->coursename}')");

            $config = new \stdClass();
            if (!empty($bi->configdata)) {
                $decoded_config = unserialize(base64_decode($bi->configdata));
                if (is_object($decoded_config)) {
                    $config = $decoded_config;
                } else if (is_array($decoded_config)) { // Por si acaso, aunque edit_form lo guarda como objeto.
                    $config = (object)$decoded_config;
                }
            }

            // 2. Verificar si la notificación del 20% está habilitada.
            if (empty($config->enable_progress20_email)) { // CAMBIADO
                mtrace("Progress 20% email DISABLED for course ID: {$bi->courseid}. Skipping."); // CAMBIADO
                continue;
            }
            mtrace("Progress 20% email ENABLED for course ID: {$bi->courseid}."); // CAMBIADO

            // 3. Verificar fechas de inicio y fin, y calcular el punto del 20%.
            if (empty($bi->coursestartdate) || empty($bi->courseenddate) || $bi->courseenddate <= $bi->coursestartdate) {
                mtrace("Course ID {$bi->courseid} has no start/end date, end date is invalid, or course has no duration. Skipping progress 20% email."); // CAMBIADO
                continue;
            }

            $course_duration = $bi->courseenddate - $bi->coursestartdate;
            if ($course_duration <= 0) { // Doble chequeo por si acaso
                mtrace("Course ID {$bi->courseid} has zero or negative duration. Skipping.");
                continue;
            }
            $milestone_20_percent_time = $bi->coursestartdate + (0.20 * $course_duration); // CAMBIADO de 0.25 a 0.20

            mtrace("Course ID {$bi->courseid}: Start: " . userdate($bi->coursestartdate) . " (" . $bi->coursestartdate . "), End: " . userdate($bi->courseenddate) . " (" . $bi->courseenddate . "), 20% Milestone: " . userdate($milestone_20_percent_time) . " (" . $milestone_20_percent_time . ")"); // CAMBIADO

            // 4. Verificar si hemos alcanzado el punto del 20% Y si aún no hemos pasado la fecha de fin del curso.
            if ($current_time_utc < $milestone_20_percent_time) { // CAMBIADO
                mtrace("Course ID {$bi->courseid}: 20% milestone not yet reached (Current: " . userdate($current_time_utc) . "). Skipping."); // CAMBIADO
                continue;
            }
            if ($current_time_utc > $bi->courseenddate) {
                 mtrace("Course ID {$bi->courseid}: Course has already ended (Current: " . userdate($current_time_utc) . "). Skipping 20% reminder."); // CAMBIADO
                 continue;
            }
            mtrace("Course ID {$bi->courseid}: 20% milestone reached or passed, and course not yet ended. Proceeding."); // CAMBIADO

            // 5. Obtener usuarios matriculados.
            $coursecontext = \context_course::instance($bi->courseid);
            $enrolled_users = get_enrolled_users(
                $coursecontext, '', 0, // Sin capacidad específica, todos los roles matriculados. Ajustar si es necesario.
                'u.id, u.username, u.firstname, u.lastname, u.email, u.mnethostid, u.suspended, u.deleted, u.confirmed, u.auth, u.lastaccess AS userlastaccess' // u.lastaccess es el acceso general al sitio
            );

            if (empty($enrolled_users)) {
                mtrace("No users found for course ID: {$bi->courseid} after get_enrolled_users call.");
                continue;
            }
            mtrace(count($enrolled_users) . " users initially fetched for course ID: {$bi->courseid}. Filtering and processing...");

            $emailsubject_template = !empty($config->progress20_email_subject) ? $config->progress20_email_subject : get_string('defaultprogress20subject', 'block_course_notifications'); // CAMBIADO
            $raw_email_body_template = !empty($config->progress20_email_body) ? $config->progress20_email_body : get_string('defaultprogress20body', 'block_course_notifications'); // CAMBIADO
            $emailbody_html_template = '';

            // Asegurarse de que $emailbody_html_template es una cadena de texto HTML.
            if (is_array($raw_email_body_template) && isset($raw_email_body_template['text'])) {
                $emailbody_html_template = $raw_email_body_template['text'];
            } else if (is_string($raw_email_body_template)) {
                $emailbody_html_template = $raw_email_body_template;
            } else {
                $emailbody_html_template = get_string('defaultprogress20body', 'block_course_notifications'); // CAMBIADO
            }
            
            $course_url_obj = new \moodle_url('/course/view.php', ['id' => $bi->courseid]);
            $course_link = $course_url_obj->out(false); // Obtiene URL sin escapar HTML.
            
            $supportuser = \core_user::get_support_user(); // Usuario desde el que se envía el correo.
            if (!$supportuser) {
                $supportuser = \core_user::get_noreply_user(); // Fallback a noreply.
            }

            foreach ($enrolled_users as $user) {
                // Filtro básico de usuario (suspendido, borrado, etc.)
                if (!empty($user->suspended) || !empty($user->deleted) || empty($user->confirmed) || $user->auth === 'nologin' || empty($user->email)) {
                    mtrace("Skipping user (basic check): {$user->username} (ID: {$user->id}) for course {$bi->courseid}. Suspended:{$user->suspended}, Deleted:{$user->deleted}, Confirmed:{$user->confirmed}, Auth:{$user->auth}, EmailEmpty:" . empty($user->email));
                    continue;
                }

                // 6. Verificar si el correo ya fue enviado para este recordatorio.
                $already_sent_params = [
                    'courseid' => $bi->courseid,
                    'userid' => $user->id,
                    'reminder_type' => 'progress20' // CAMBIADO
                ];
                $already_sent = $DB->get_record('block_cn_progress_reminders', $already_sent_params);

                if ($already_sent) {
                    mtrace("Progress 20% email ALREADY LOGGED for user {$user->username} (ID: {$user->id}), course {$bi->courseid}. Status: {$already_sent->status}. Skipping."); // CAMBIADO
                    continue;
                }

                // 7. Verificar si el alumno ha "comenzado" el curso (accedido al curso después de su inicio).
                $course_user_lastaccess = $DB->get_field('user_lastaccess', 'timeaccess', ['userid' => $user->id, 'courseid' => $bi->courseid]);

                if ($course_user_lastaccess && $course_user_lastaccess >= $bi->coursestartdate) {
                    mtrace("User {$user->username} (ID: {$user->id}) has accessed course {$bi->courseid} on/after start date (Last course access: " . userdate($course_user_lastaccess) . "). Skipping 20% reminder."); // CAMBIADO
                    // Opcionalmente, para no volver a chequear este usuario si no queremos enviarle, podríamos insertar un log con estado 'not_applicable' o 'accessed'.
                    // Por ahora, simplemente lo saltamos para este envío.
                    continue;
                } else {
                     mtrace("User {$user->username} (ID: {$user->id}) has NO RECENT ACCESS for course {$bi->courseid} (DB course lastaccess: " . ($course_user_lastaccess ? userdate($course_user_lastaccess) . " [" . $course_user_lastaccess . "]" : 'none') . ", Course start: " . userdate($bi->coursestartdate) . " [" . $bi->coursestartdate . "]). Preparing 20% reminder."); // CAMBIADO
                }

                // 8. Enviar correo y registrar.
                mtrace("Preparing to send 20% progress reminder to user: {$user->username} (ID: {$user->id}, Email: {$user->email}) for course {$bi->courseid}"); // CAMBIADO
                $messagevars = [
                    '{coursename}'       => $bi->coursename,
                    '{studentfirstname}' => $user->firstname,
                    '{studentlastname}'  => $user->lastname,
                    '{courselink}'       => $course_link,
                ];

                $subject_processed = str_replace(array_keys($messagevars), array_values($messagevars), $emailsubject_template);
                $body_html_processed = str_replace(array_keys($messagevars), array_values($messagevars), $emailbody_html_template);
                $body_plain_processed = html_to_text($body_html_processed); // Moodle limpiará esto.

                $email_status = 'failed'; // Por defecto.
                $email_sent_successfully = false;
                try {
                    $email_sent_successfully = email_to_user(
                        $user,              // Objeto del usuario destinatario.
                        $supportuser,       // Objeto del usuario remitente.
                        $subject_processed, // Asunto del correo.
                        $body_plain_processed, // Cuerpo del correo en texto plano.
                        $body_html_processed   // Cuerpo del correo en HTML.
                    );

                    if ($email_sent_successfully) {
                        mtrace("20% progress email successfully sent to {$user->username} (ID: {$user->id}) for course {$bi->courseid}."); // CAMBIADO
                        $email_status = 'sent';
                    } else {
                        mtrace("ERROR: 20% progress email_to_user reported failure for user {$user->username} (ID: {$user->id}), course {$bi->courseid}."); // CAMBIADO
                    }
                } catch (\Exception $e) { // Captura excepciones más generales.
                     mtrace("EXCEPTION during 20% progress email_to_user for user {$user->username} (ID: {$user->id}), course {$bi->courseid}: " . $e->getMessage()); // CAMBIADO
                }

                $log_record = new \stdClass();
                $log_record->courseid = $bi->courseid;
                $log_record->userid = $user->id;
                $log_record->timesent = $current_time_utc; // Usar el tiempo actual para el log.
                $log_record->status = $email_status;
                $log_record->reminder_type = 'progress20'; // CAMBIADO Tipo de recordatorio.
                
                try {
                    $DB->insert_record('block_cn_progress_reminders', $log_record, false);
                    mtrace("Logged 20% progress email attempt (status: {$email_status}) for user {$user->id}, course {$bi->courseid}."); // CAMBIADO
                } catch (\dml_exception $e) { 
                    mtrace("ERROR: Could not insert 20% progress log record for user {$user->id}, course {$bi->courseid}. DML Exception: " . $e->getMessage()); // CAMBIADO
                }
            } // Fin foreach $enrolled_users
        } // Fin foreach $block_instances

        mtrace("Cron task 'send_progress20_emails' from block_course_notifications finished."); // MENSAJE CAMBIADO
    }
}