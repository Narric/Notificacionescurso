<?php
namespace block_course_notifications\task;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir.'/moodlelib.php');
require_once($CFG->libdir.'/messagelib.php');
require_once($CFG->libdir.'/modinfolib.php');

class send_bbb_reminder_emails extends \core\task\scheduled_task {

    public function get_name() {
        return get_string('send_bbb_reminder_emails_task', 'block_course_notifications');
    }

    public function execute() {
        global $DB, $CFG;

        mtrace("Cron task 'send_bbb_reminder_emails' (daily check) from block_course_notifications started.");
        
        // Obtener el inicio y fin del día actual en la zona horaria del usuario/servidor.
        // Usaremos timestamps UTC para las comparaciones con openingtime, asumiendo que openingtime también es UTC.
        $today_start = strtotime('today', time()); // Medianoche de hoy (00:00:00)
        $today_end = strtotime('tomorrow', $today_start) - 1; // Fin de hoy (23:59:59)
        // Alternativamente, para asegurar que se consideran las zonas horarias correctamente al comparar con $bbb->openingtime,
        // es mejor normalizar las fechas. Moodle guarda los timestamps en UTC.
        // $today_start_user_timezone = usergetmidnight(time()); // Medianoche en la zona horaria del usuario actual (del cron)
        // $today_end_user_timezone = usergetmidnight(time() + DAYSECS);

        // Vamos a usar timestamps UTC para el rango del día actual.
        // El $bbb->openingtime se asume que es un timestamp UTC.
        $current_processing_time = time(); // Para el log de timesent
        $today_midnight_utc = gmmktime(0, 0, 0, (int)gmdate('n', $current_processing_time), (int)gmdate('j', $current_processing_time), (int)gmdate('Y', $current_processing_time));
        $tomorrow_midnight_utc = $today_midnight_utc + DAYSECS; // DAYSECS es 24 * 60 * 60

        mtrace("Checking for BBB sessions scheduled between: " . gmdate('Y-m-d H:i:s', $today_midnight_utc) . " UTC and " . gmdate('Y-m-d H:i:s', $tomorrow_midnight_utc -1) . " UTC");


        $block_instances = $DB->get_records_sql(
            "SELECT bi.id AS bi_id, bi.configdata, bi.parentcontextid,
                    c.id AS courseid, c.fullname AS coursename
             FROM {block_instances} bi
             JOIN {context} ctx ON bi.parentcontextid = ctx.id
             JOIN {course} c ON ctx.instanceid = c.id
             WHERE bi.blockname = :blockname AND ctx.contextlevel = :contextlevel",
            ['blockname' => 'course_notifications', 'contextlevel' => CONTEXT_COURSE]
        );

        if (empty($block_instances)) {
            mtrace("No instances of block_course_notifications found. Task finished.");
            return;
        }

        foreach ($block_instances as $bi) {
            $config = new \stdClass();
            if (!empty($bi->configdata)) {
                $decoded_config = unserialize(base64_decode($bi->configdata));
                $config = is_object($decoded_config) ? $decoded_config : (object)$decoded_config;
            }

            if (empty($config->enable_bbbupcoming_email)) {
                // mtrace("BBB daily reminder email DISABLED for block instance ID {$bi->bi_id} in course ID: {$bi->courseid}. Skipping.");
                continue;
            }
            mtrace("BBB daily reminder email ENABLED for block instance ID {$bi->bi_id} in course ID: {$bi->courseid}.");

            $modinfo = get_fast_modinfo($bi->courseid);
            $bbb_sessions_today = [];
            foreach ($modinfo->get_cms() as $cm) {
                if ($cm->modname == 'bigbluebuttonbn' && $cm->uservisible) {
                    $bbb_record = $DB->get_record('bigbluebuttonbn', ['id' => $cm->instance]);
                    // Verificar si openingtime está definido y cae dentro del día de HOY (UTC)
                    if ($bbb_record && !empty($bbb_record->openingtime) && 
                        $bbb_record->openingtime >= $today_midnight_utc && 
                        $bbb_record->openingtime < $tomorrow_midnight_utc) {
                        
                        $bbb_sessions_today[] = ['cm' => $cm, 'bbb_record' => $bbb_record];
                    }
                }
            }

            if (empty($bbb_sessions_today)) {
                // mtrace("No visible BigBlueButtonBN activities scheduled for today in course ID: {$bi->courseid}.");
                continue;
            }
            mtrace(count($bbb_sessions_today) . " BBB sessions found scheduled for today in course ID: {$bi->courseid}.");


            $emailsubject_template = !empty($config->bbbupcoming_email_subject) ? $config->bbbupcoming_email_subject : get_string('defaultbbbupcomingsubject', 'block_course_notifications');
            $raw_email_body_template = !empty($config->bbbupcoming_email_body) ? $config->bbbupcoming_email_body : get_string('defaultbbbupcomingbody', 'block_course_notifications');
            $emailbody_html_template = is_array($raw_email_body_template) && isset($raw_email_body_template['text']) ? $raw_email_body_template['text'] : (is_string($raw_email_body_template) ? $raw_email_body_template : get_string('defaultbbbupcomingbody', 'block_course_notifications'));
            
            $coursecontext = \context_course::instance($bi->courseid);
            $enrolled_users = get_enrolled_users(
                $coursecontext, '', 0,
                'u.id, u.username, u.firstname, u.lastname, u.email, u.mnethostid, u.suspended, u.deleted, u.confirmed, u.auth'
            );

            if (empty($enrolled_users)) {
                // mtrace("No users found for course ID: {$bi->courseid} to send BBB daily reminders.");
                continue;
            }
            
            $supportuser = \core_user::get_support_user() ?: \core_user::get_noreply_user();

            foreach ($bbb_sessions_today as $bbb_data) {
                $cm = $bbb_data['cm'];
                $bbb = $bbb_data['bbb_record'];

                mtrace("Processing BBB session '{$bbb->name}' (CMID: {$cm->id}) in course {$bi->courseid}, scheduled for today at " . userdate($bbb->openingtime, get_string('strftimetime')) . " (user timezone).");

                $session_link_url = new \moodle_url('/mod/bigbluebuttonbn/view.php', ['id' => $cm->id]);
                $session_link = $session_link_url->out(false);
                // Formatear la hora de inicio en la zona horaria del usuario para el correo
                $starttime_formatted_user = userdate($bbb->openingtime, get_string('strftimetime')); // Solo la hora, en zona horaria del usuario (del que ejecuta el cron)

                foreach ($enrolled_users as $user) {
                    if (!empty($user->suspended) || !empty($user->deleted) || empty($user->confirmed) || $user->auth === 'nologin' || empty($user->email)) {
                        continue;
                    }

                    $reminder_type_for_log = 'bbb_today'; // Nuevo tipo de recordatorio
                    $already_sent = $DB->get_record('block_cn_progress_reminders', [
                        'courseid'      => $bi->courseid,
                        'userid'        => $user->id,
                        'cmid'          => $cm->id, 
                        'reminder_type' => $reminder_type_for_log 
                    ]);

                    if ($already_sent) {
                        // mtrace("BBB daily reminder for session CMID {$cm->id} ALREADY LOGGED for user {$user->username}. Skipping.");
                        continue;
                    }

                    mtrace("Preparing BBB daily reminder for user {$user->username} (ID: {$user->id}) for session '{$bbb->name}' (CMID: {$cm->id}).");

                    $messagevars = [
                        '{coursename}'       => $bi->coursename,
                        '{studentfirstname}' => $user->firstname,
                        '{studentlastname}'  => $user->lastname,
                        '{sessionname}'      => $bbb->name,
                        '{starttime}'        => $starttime_formatted_user, // Hora en la zona del usuario
                        '{sessionlink}'      => $session_link,
                    ];

                    $subject_processed = str_replace(array_keys($messagevars), array_values($messagevars), $emailsubject_template);
                    $body_html_processed = str_replace(array_keys($messagevars), array_values($messagevars), $emailbody_html_template);
                    $body_plain_processed = html_to_text($body_html_processed);

                    $email_status = 'failed';
                    try {
                        if (email_to_user($user, $supportuser, $subject_processed, $body_plain_processed, $body_html_processed)) {
                            mtrace("BBB daily reminder email successfully sent to {$user->username} (ID: {$user->id}) for session '{$bbb->name}'.");
                            $email_status = 'sent';
                        } else {
                            mtrace("ERROR: BBB daily reminder email_to_user reported failure for user {$user->username} (ID: {$user->id}) for session '{$bbb->name}'.");
                        }
                    } catch (\Exception $e) {
                        mtrace("EXCEPTION during BBB daily reminder email_to_user for user {$user->username} (ID: {$user->id}), session '{$bbb->name}': " . $e->getMessage());
                    }

                    $log_record = new \stdClass();
                    $log_record->courseid = $bi->courseid;
                    $log_record->userid = $user->id;
                    $log_record->cmid = $cm->id;
                    $log_record->timesent = $current_processing_time; // Usar el tiempo de inicio del cron para consistencia
                    $log_record->status = $email_status;
                    $log_record->reminder_type = $reminder_type_for_log; 
                    
                    try {
                        $DB->insert_record('block_cn_progress_reminders', $log_record, false);
                        mtrace("Logged BBB daily reminder email attempt (status: {$email_status}, type: {$reminder_type_for_log}) for user {$user->id}, session CMID {$cm->id}.");
                    } catch (\dml_exception $e) {
                        mtrace("ERROR: Could not insert BBB daily reminder log record (type: {$reminder_type_for_log}) for user {$user->id}, session CMID {$cm->id}. DML Exception: " . $e->getMessage());
                    }
                } 
            } 
        } 
        mtrace("Cron task 'send_bbb_reminder_emails' (daily check) from block_course_notifications finished.");
    }
}