<?php
namespace block_course_notifications\task;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir.'/moodlelib.php');
require_once($CFG->libdir.'/messagelib.php');
require_once($CFG->libdir.'/modinfolib.php'); // Para get_fast_modinfo

class send_bbb_reminder_emails extends \core\task\scheduled_task {

    public function get_name() {
        return get_string('send_bbb_reminder_emails_task', 'block_course_notifications');
    }

    public function execute() {
        global $DB, $CFG;

        mtrace("Cron task 'send_bbb_reminder_emails' from block_course_notifications started.");
        $currenttime = time();

        // Obtener la medianoche de hoy y de mañana para definir el rango del día actual.
        // Esto es crucial para manejar correctamente las zonas horarias.
        // Asumimos que las fechas de openingtime en BBB están en UTC (lo cual es estándar en Moodle).
        $today_start_utc = strtotime('today midnight', $currenttime); // 00:00:00 UTC de hoy
        $tomorrow_start_utc = strtotime('tomorrow midnight', $currenttime); // 00:00:00 UTC de mañana

        mtrace("Checking for BBB sessions between: " . userdate($today_start_utc) . " AND " . userdate($tomorrow_start_utc -1));

        $block_instances = $DB->get_records_sql(
            "SELECT bi.id AS bi_id, bi.configdata, bi.parentcontextid,
                    c.id AS courseid, c.fullname AS coursename
             FROM {block_instances} bi
             JOIN {context} ctx ON bi.parentcontextid = ctx.id
             JOIN {course} c ON ctx.instanceid = c.id
             WHERE bi.blockname = :blockname AND ctx.contextlevel = :contextlevel",
            ['blockname' => 'course_notifications', 'contextlevel' => CONTEXT_COURSE]
        );

        if (empty($block_instances)) {
            mtrace("No instances of block_course_notifications found. Task finished.");
            return;
        }

        foreach ($block_instances as $bi) {
            mtrace("Processing block instance ID: {$bi->bi_id} for course ID: {$bi->courseid} ('{$bi->coursename}')");

            $config = new \stdClass();
            if (!empty($bi->configdata)) {
                $decoded_config = unserialize(base64_decode($bi->configdata));
                $config = is_object($decoded_config) ? $decoded_config : (object)$decoded_config;
            }

            if (empty($config->enable_bbb_reminder_email)) {
                mtrace("BigBlueButton session reminder email DISABLED for course ID: {$bi->courseid}. Skipping.");
                continue;
            }
            mtrace("BigBlueButton session reminder email ENABLED for course ID: {$bi->courseid}.");

            // Obtener todas las actividades BBB visibles para este curso cuyas fechas de apertura caen hoy.
            // Necesitamos unir con course_modules para verificar la visibilidad.
            $sql = "SELECT bbb.id AS bbbinstanceid, bbb.name AS bbbname, bbb.openingtime,
                           cm.id AS cmid
                    FROM {bigbluebuttonbn} bbb
                    JOIN {course_modules} cm ON cm.instance = bbb.id
                    WHERE bbb.course = :courseid
                      AND cm.module = (SELECT id FROM {modules} WHERE name = 'bigbluebuttonbn')
                      AND cm.visible = 1
                      AND bbb.openingtime >= :todaystart
                      AND bbb.openingtime < :tomorrowstart";
            
            $params = [
                'courseid' => $bi->courseid,
                'todaystart' => $today_start_utc,
                'tomorrowstart' => $tomorrow_start_utc
            ];

            $bbb_sessions_today = $DB->get_records_sql($sql, $params);

            if (empty($bbb_sessions_today)) {
                mtrace("No visible BigBlueButton sessions scheduled for today in course ID: {$bi->courseid}.");
                continue;
            }

            mtrace(count($bbb_sessions_today) . " BigBlueButton sessions found for today in course ID: {$bi->courseid}.");

            $coursecontext = \context_course::instance($bi->courseid);
            $enrolled_users = get_enrolled_users(
                $coursecontext, '', 0,
                'u.id, u.username, u.firstname, u.lastname, u.email, u.mnethostid, u.suspended, u.deleted, u.confirmed, u.auth'
            );

            if (empty($enrolled_users)) {
                mtrace("No users found for course ID: {$bi->courseid}.");
                continue;
            }

            $emailsubject_template = !empty($config->bbb_reminder_email_subject) ? $config->bbb_reminder_email_subject : get_string('defaultbbbremindersubject', 'block_course_notifications');
            $raw_email_body_template = !empty($config->bbb_reminder_email_body) ? $config->bbb_reminder_email_body : get_string('defaultbbbreminderbody', 'block_course_notifications');
            $emailbody_html_template = is_array($raw_email_body_template) && isset($raw_email_body_template['text']) ? $raw_email_body_template['text'] : (is_string($raw_email_body_template) ? $raw_email_body_template : get_string('defaultbbbreminderbody', 'block_course_notifications'));

            $course_url_obj = new \moodle_url('/course/view.php', ['id' => $bi->courseid]);
            $course_link = $course_url_obj->out(false);
            $supportuser = \core_user::get_support_user() ?: \core_user::get_noreply_user();

            foreach ($bbb_sessions_today as $session) {
                mtrace("Processing session: '{$session->bbbname}' (ID: {$session->bbbinstanceid}, CMID: {$session->cmid}), Opening time: " . userdate($session->openingtime));
                
                $session_url_obj = new \moodle_url('/mod/bigbluebuttonbn/view.php', ['id' => $session->cmid]);
                $session_link = $session_url_obj->out(false);
                // Formatear la hora de inicio de la sesión para el correo (ej. 14:30). Usar userdate con formato de hora.
                $session_start_time_formatted = userdate($session->openingtime, get_string('strftimetime'));


                foreach ($enrolled_users as $user) {
                    if (!empty($user->suspended) || !empty($user->deleted) || empty($user->confirmed) || $user->auth === 'nologin' || empty($user->email)) {
                        mtrace("Skipping user (basic check): {$user->username} (ID: {$user->id}) for BBB reminder, course {$bi->courseid}.");
                        continue;
                    }

                    // Usaremos el ID de la instancia del módulo (cmid) para hacer el log único por sesión y usuario
                    // y un tipo de recordatorio específico.
                    $reminder_type_for_log = 'bbb_reminder_cm' . $session->cmid;
                    
                    // Verificar si ya se envió para esta sesión específica a este usuario hoy.
                    // (No usaremos la tabla block_cn_progress_reminders directamente como está ahora
                    //  porque su índice unique es (courseid, userid, reminder_type).
                    //  Para sesiones múltiples en un día, necesitaríamos un log más específico,
                    //  o cambiar la tabla de log para incluir instanceid o cmid).
                    //  Por simplicidad, vamos a registrar en block_cn_progress_reminders
                    //  y la clave única evitará duplicados *por día* si solo hay una sesión bbb
                    //  con el mismo reminder_type. Para manejar múltiples sesiones BBB el mismo día
                    //  para el mismo curso, el reminder_type_for_log es crucial.
                    //  El campo reminder_type tiene LENGTH 20. 'bbb_reminder_cm' + cmid podría superarlo.
                    //  Vamos a usar un hash o un identificador más corto si es necesario, o aumentamos el tamaño del campo.
                    //  Por ahora, intentaremos con el cmid, asumiendo que no será demasiado largo.
                    //  Alternativa: crear una tabla específica para logs de BBB.
                    //  Por ahora, usamos `block_cn_progress_reminders` y `reminder_type` será 'bbb_today_s' . $session->bbbinstanceid;
                    //  Asegurarse que esto no exceda el tamaño de 'reminder_type' (char 20)

                    $unique_reminder_id_for_session = 'bbb_s' . $session->bbbinstanceid; // Ej: bbb_s123 (bbb + id instancia bbb)
                    if (strlen($unique_reminder_id_for_session) > 20) {
                        $unique_reminder_id_for_session = substr('bbb_s' . md5($session->bbbinstanceid), 0, 20); // fallback a hash si es muy largo
                    }


                    $already_sent = $DB->get_record('block_cn_progress_reminders', [
                        'courseid'      => $bi->courseid,
                        'userid'        => $user->id,
                        'reminder_type' => $unique_reminder_id_for_session 
                    ]);

                    if ($already_sent) {
                        mtrace("BigBlueButton session '{$session->bbbname}' reminder ALREADY LOGGED (type: {$unique_reminder_id_for_session}) for user {$user->username} (ID: {$user->id}), course {$bi->courseid}. Skipping.");
                        continue;
                    }

                    mtrace("Preparing to send BBB reminder for session '{$session->bbbname}' to user: {$user->username} (ID: {$user->id}, Email: {$user->email})");

                    $messagevars = [
                        '{coursename}'       => $bi->coursename,
                        '{studentfirstname}' => $user->firstname,
                        '{studentlastname}'  => $user->lastname,
                        '{courselink}'       => $course_link,
                        '{sessionname}'      => $session->bbbname,
                        '{starttime}'        => $session_start_time_formatted,
                        '{sessionlink}'      => $session_link,
                    ];

                    $subject_processed = str_replace(array_keys($messagevars), array_values($messagevars), $emailsubject_template);
                    $body_html_processed = str_replace(array_keys($messagevars), array_values($messagevars), $emailbody_html_template);
                    $body_plain_processed = html_to_text($body_html_processed);

                    $email_status = 'failed';
                    try {
                        if (email_to_user($user, $supportuser, $subject_processed, $body_plain_processed, $body_html_processed)) {
                            mtrace("BBB session reminder email successfully sent to {$user->username} for session '{$session->bbbname}'.");
                            $email_status = 'sent';
                        } else {
                            mtrace("ERROR: BBB session reminder email_to_user reported failure for user {$user->username}, session '{$session->bbbname}'.");
                        }
                    } catch (\Exception $e) {
                        mtrace("EXCEPTION during BBB session reminder email_to_user for user {$user->username}, session '{$session->bbbname}': " . $e->getMessage());
                    }

                    $log_record = new \stdClass();
                    $log_record->courseid = $bi->courseid;
                    $log_record->userid = $user->id;
                    $log_record->timesent = $currenttime;
                    $log_record->status = $email_status;
                    $log_record->reminder_type = $unique_reminder_id_for_session; 
                    
                    try {
                        $DB->insert_record('block_cn_progress_reminders', $log_record, false);
                        mtrace("Logged BBB session reminder attempt (status: {$email_status}, type: {$unique_reminder_id_for_session}) for user {$user->id}, course {$bi->courseid}.");
                    } catch (\dml_exception $e) {
                        // Si falla por clave duplicada (otro proceso lo insertó justo ahora), está bien.
                        if ($DB->is_unique_constraint_violation($e)) {
                             mtrace("Log for BBB session reminder (type: {$unique_reminder_id_for_session}) for user {$user->id} already exists (concurrent insert).");
                        } else {
                             mtrace("ERROR: Could not insert BBB session reminder log record (type: {$unique_reminder_id_for_session}) for user {$user->id}. DML Exception: " . $e->getMessage());
                        }
                    }
                } // Fin foreach $enrolled_users
            } // Fin foreach $bbb_sessions_today
        } // Fin foreach $block_instances
        mtrace("Cron task 'send_bbb_reminder_emails' from block_course_notifications finished.");
    }
}