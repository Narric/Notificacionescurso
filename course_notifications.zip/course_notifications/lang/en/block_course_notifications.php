<?php
defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Course Notifications';
$string['blocktitle'] = 'Course Notifications'; // Un título por defecto para el bloque si no se configura uno.

// Cadenas para edit_form.php
$string['coursestartsettings'] = 'Course Start Notification Settings';
$string['enablestartemail'] = 'Enable email on course start';
$string['enablestartemail_help'] = 'If checked, an email will be sent to all enrolled students when the course officially starts (according to the course start date).';
$string['startemailsubject'] = 'Email Subject';
$string['startemailsubject_help'] = 'Subject for the course start email. Available placeholders: {coursename}, {studentfirstname}, {studentlastname}, {courselink}';
$string['defaultstartemailsubject'] = 'Welcome to {coursename}!';
$string['startemailbody'] = 'Email Body (HTML)';
$string['startemailbody_help'] = 'Body for the course start email. Available placeholders: {coursename}, {studentfirstname}, {studentlastname}, {courselink}. Use HTML for formatting.';
$string['defaultstartemailbody'] = '<p>Dear {studentfirstname},</p><p>Welcome to the course "{coursename}". We are excited to have you!</p><p>The course is now officially open.</p><p>You can access the course here: {courselink}</p><p>Regards,<br>The Teaching Team</p>';
$string['required'] = 'This field is required.'; // Cadena para validación

// Cadenas para la tarea programada (cron task)
$string['send_start_emails_task'] = 'Send Course Start Emails';

// Cadenas opcionales para get_content() en la clase del bloque
$string['start_email_enabled_desc'] = 'Course start emails are currently ENABLED for this course.';
$string['start_email_disabled_desc'] = 'Course start emails are currently DISABLED for this course.';

// Cadenas para la base de datos (si necesitas describir tablas/campos en la interfaz de admin)
// $string['table:block_cn_initial_sents'] = 'Log of initial course start emails';
// $string['field:courseid'] = 'Course ID';
// $string['field:userid'] = 'User ID';
// $string['field:timesent'] = 'Time Sent';
// $string['field:status'] = 'Status';
// Cadenas para edit_form.php (Recordatorio de Progreso del 25%)
$string['progressremindersettings'] = 'Course Progress Reminder Settings (20%)'; // Cambiado
$string['enableprogress20email'] = 'Enable 20% progress reminder email'; // Cambiado nombre de string y texto
$string['enableprogress20email_help'] = 'If checked, an email will be sent to enrolled students who have not yet started the course when approximately 20% of the course duration has passed (requires course start and end dates to be set).'; // Cambiado
$string['progress20emailsubject'] = '20% Progress Email Subject'; // Cambiado nombre de string y texto
$string['progress20emailsubject_help'] = 'Subject for the 20% progress reminder email. Placeholders: {coursename}, {studentfirstname}, {studentlastname}, {courselink}'; // Cambiado
$string['defaultprogress20subject'] = 'Reminder: {coursename} is 20% underway!'; // Cambiado nombre de string y texto
$string['progress20emailbody'] = '20% Progress Email Body (HTML)'; // Cambiado nombre de string y texto
$string['progress20emailbody_help'] = 'Body for the 20% progress reminder. Placeholders: {coursename}, {studentfirstname}, {studentlastname}, {courselink}. Use HTML for formatting.'; // Cambiado
$string['defaultprogress20body'] = '<p>Dear {studentfirstname},</p><p>Just a friendly reminder that the course "{coursename}" is underway, and about 20% of its duration has passed.</p><p>We noticed you haven\'t started yet. There\'s still plenty of time to catch up and engage with the material!</p><p>Access the course here: {courselink}</p><p>We look forward to seeing you in the course!</p><p>Regards,<br>The Teaching Team</p>'; // Cambiado nombre de string y texto
$string['send_progress20_emails_task'] = 'Send 20% Course Progress Reminder Emails'; // Cambiado nombre de string y texto
// Course Completion Notification Settings
$string['coursecompletionsettings'] = 'Course Completion Notification Settings';
$string['enablecompletionemail'] = 'Enable course completion email';
$string['enablecompletionemail_help'] = 'If checked, an email will be sent to students when they have completed all quizzes in the course (based on each quiz\'s activity completion settings).';
$string['completionemailsubject'] = 'Course Completion Email Subject';
$string['completionemailsubject_help'] = 'Subject for the course completion email. Placeholders: {coursename}, {studentfirstname}, {studentlastname}, {courselink}, {completiondate}';
$string['defaultcompletionsubject'] = 'Congratulations on completing {coursename}!';
$string['completionemailbody'] = 'Course Completion Email Body (HTML)';
$string['completionemailbody_help'] = 'Body for the course completion email. Placeholders: {coursename}, {studentfirstname}, {studentlastname}, {courselink}, {completiondate}. Use HTML for formatting.';
$string['defaultcompletionbody'] = '<p>Dear {studentfirstname},</p><p>Congratulations on successfully completing the course "{coursename}" on {completiondate}!</p><p>We commend you on your hard work and dedication.</p><p>You can review the course content here: {courselink}</p><p>Best regards,<br>The Teaching Team</p>';

// Scheduled task string
$string['send_completion_emails_task'] = 'Send Course Completion Emails';

// BBB Session Start Reminder Settings
$string['bbbupcomingmeetingsettings'] = 'BigBlueButton Session Start Reminder Settings';
$string['enablebbbupcomingemail'] = 'Enable BBB session start reminder (5 min)';
$string['enablebbbupcomingemail_help'] = 'If checked, an email will be sent to enrolled students 5 minutes before a scheduled BigBlueButton session with a defined opening time is due to start.';
$string['bbbupcomingemailsubject'] = 'BBB Session Starting Soon Subject';
$string['bbbupcomingemailsubject_help'] = 'Subject for the BBB session start reminder. Placeholders: {coursename}, {studentfirstname}, {studentlastname}, {sessionname}, {starttime}, {sessionlink}';
$string['defaultbbbupcomingsubject'] = 'Reminder: {sessionname} in {coursename} is starting in 5 minutes!';
$string['bbbupcomingemailbody'] = 'BBB Session Starting Soon Body (HTML)';
$string['bbbupcomingemailbody_help'] = 'Body for the BBB session start reminder. Placeholders: {coursename}, {studentfirstname}, {studentlastname}, {sessionname}, {starttime}, {sessionlink}. Use HTML for formatting.';
$string['defaultbbbupcomingbody'] = '<p>Dear {studentfirstname},</p><p>This is a reminder that the BigBlueButton session "<strong>{sessionname}</strong>" in the course "<strong>{coursename}</strong>" is scheduled to start in approximately 5 minutes, at {starttime}.</p><p>You can join the session here: {sessionlink}</p><p>We look forward to seeing you!</p><p>Regards,<br>The Teaching Team</p>';

// Scheduled task string
$string['send_bbb_reminder_emails_task'] = 'Send BBB Session Start Reminder Emails';