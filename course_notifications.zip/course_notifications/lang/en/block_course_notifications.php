<?php
defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Course Notifications';
$string['blocktitle'] = 'Course Notifications'; // Un título por defecto para el bloque si no se configura uno.

// Cadenas para edit_form.php
$string['coursestartsettings'] = 'Course Start Notification Settings';
$string['enablestartemail'] = 'Enable email on course start';
$string['enablestartemail_help'] = 'If checked, an email will be sent to all enrolled students when the course officially starts (according to the course start date).';
$string['startemailsubject'] = 'Email Subject';
$string['startemailsubject_help'] = 'Subject for the course start email. Available placeholders: {coursename}, {studentfirstname}, {studentlastname}, {courselink}';
$string['defaultstartemailsubject'] = 'Welcome to {coursename}!';
$string['startemailbody'] = 'Email Body (HTML)';
$string['startemailbody_help'] = 'Body for the course start email. Available placeholders: {coursename}, {studentfirstname}, {studentlastname}, {courselink}. Use HTML for formatting.';
$string['defaultstartemailbody'] = '<p>Dear {studentfirstname},</p><p>Welcome to the course "{coursename}". We are excited to have you!</p><p>The course is now officially open.</p><p>You can access the course here: {courselink}</p><p>Regards,<br>The Teaching Team</p>';
$string['required'] = 'This field is required.'; // Cadena para validación

// Cadenas para la tarea programada (cron task)
$string['send_start_emails_task'] = 'Send Course Start Emails';

// Cadenas opcionales para get_content() en la clase del bloque
$string['start_email_enabled_desc'] = 'Course start emails are currently ENABLED for this course.';
$string['start_email_disabled_desc'] = 'Course start emails are currently DISABLED for this course.';

// Cadenas para la base de datos (si necesitas describir tablas/campos en la interfaz de admin)
// $string['table:block_cn_initial_sents'] = 'Log of initial course start emails';
// $string['field:courseid'] = 'Course ID';
// $string['field:userid'] = 'User ID';
// $string['field:timesent'] = 'Time Sent';
// $string['field:status'] = 'Status';