<?php
defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Notificaciones del Curso';
$string['blocktitle'] = 'Notificaciones del Curso'; // Título por defecto para el bloque

// Cadenas para edit_form.php
$string['coursestartsettings'] = 'Configuración de Notificación de Inicio de Curso';
$string['enablestartemail'] = 'Habilitar correo al inicio del curso';
$string['enablestartemail_help'] = 'Si se marca, se enviará un correo a todos los alumnos matriculados cuando el curso comience oficialmente (según la fecha de inicio del curso).';
$string['startemailsubject'] = 'Asunto del Correo';
$string['startemailsubject_help'] = 'Asunto para el correo de inicio de curso. Marcadores de posición disponibles: {coursename}, {studentfirstname}, {studentlastname}, {courselink}';
$string['defaultstartemailsubject'] = '¡Bienvenido/a a {coursename}!';
$string['startemailbody'] = 'Cuerpo del Correo (HTML)';
$string['startemailbody_help'] = 'Cuerpo para el correo de inicio de curso. Marcadores de posición disponibles: {coursename}, {studentfirstname}, {studentlastname}, {courselink}. Use HTML para el formato.';
$string['defaultstartemailbody'] = '<p>Estimado/a {studentfirstname},</p><p>Bienvenido/a al curso "{coursename}". ¡Estamos encantados de tenerte!</p><p>El curso ya está oficialmente abierto.</p><p>Puedes acceder al curso aquí: {courselink}</p><p>Saludos,<br>El Equipo Docente</p>';
$string['required'] = 'Este campo es obligatorio.'; // Cadena para validación

// Cadenas para la tarea programada (cron task)
$string['send_start_emails_task'] = 'Enviar Correos de Inicio de Curso';

// Cadenas opcionales para get_content() en la clase del bloque
$string['start_email_enabled_desc'] = 'Los correos de inicio de curso están HABILITADOS para este curso.';
$string['start_email_disabled_desc'] = 'Los correos de inicio de curso están DESHABILITADOS para este curso.';

// Cadenas para la base de datos (si necesitas describir tablas/campos en la interfaz de admin)
// $string['table:block_cn_initial_sents'] = 'Registro de correos iniciales de inicio de curso';
// $string['field:courseid'] = 'ID del Curso';
// $string['field:userid'] = 'ID del Usuario';
// $string['field:timesent'] = 'Fecha de Envío';
// $string['field:status'] = 'Estado';