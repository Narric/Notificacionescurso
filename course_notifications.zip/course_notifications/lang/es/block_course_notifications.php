<?php
defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Notificaciones del Curso';
$string['blocktitle'] = 'Notificaciones del Curso'; // Título por defecto para el bloque

// Cadenas para edit_form.php
$string['coursestartsettings'] = 'Configuración de Notificación de Inicio de Curso';
$string['enablestartemail'] = 'Habilitar correo al inicio del curso';
$string['enablestartemail_help'] = 'Si se marca, se enviará un correo a todos los alumnos matriculados cuando el curso comience oficialmente (según la fecha de inicio del curso).';
$string['startemailsubject'] = 'Asunto del Correo';
$string['startemailsubject_help'] = 'Asunto para el correo de inicio de curso. Marcadores de posición disponibles: {coursename}, {studentfirstname}, {studentlastname}, {courselink}';
$string['defaultstartemailsubject'] = '¡Bienvenido/a a {coursename}!';
$string['startemailbody'] = 'Cuerpo del Correo (HTML)';
$string['startemailbody_help'] = 'Cuerpo para el correo de inicio de curso. Marcadores de posición disponibles: {coursename}, {studentfirstname}, {studentlastname}, {courselink}. Use HTML para el formato.';
$string['defaultstartemailbody'] = '<p>Estimado/a {studentfirstname},</p><p>Bienvenido/a al curso "{coursename}". ¡Estamos encantados de tenerte!</p><p>El curso ya está oficialmente abierto.</p><p>Puedes acceder al curso aquí: {courselink}</p><p>Saludos,<br>El Equipo Docente</p>';
$string['required'] = 'Este campo es obligatorio.'; // Cadena para validación

// Cadenas para la tarea programada (cron task)
$string['send_start_emails_task'] = 'Enviar Correos de Inicio de Curso';

// Cadenas opcionales para get_content() en la clase del bloque
$string['start_email_enabled_desc'] = 'Los correos de inicio de curso están HABILITADOS para este curso.';
$string['start_email_disabled_desc'] = 'Los correos de inicio de curso están DESHABILITADOS para este curso.';

// Cadenas para la base de datos (si necesitas describir tablas/campos en la interfaz de admin)
// $string['table:block_cn_initial_sents'] = 'Registro de correos iniciales de inicio de curso';
// $string['field:courseid'] = 'ID del Curso';
// $string['field:userid'] = 'ID del Usuario';
// $string['field:timesent'] = 'Fecha de Envío';
// $string['field:status'] = 'Estado';
// Cadenas para edit_form.php (Recordatorio de Progreso del 25%)
$string['progressremindersettings'] = 'Configuración de Recordatorio de Progreso del Curso (20%)'; // Cambiado
$string['enableprogress20email'] = 'Habilitar correo de recordatorio del 20% de progreso'; // Cambiado nombre de string y texto
$string['enableprogress20email_help'] = 'Si se marca, se enviará un correo a los alumnos matriculados que aún no hayan comenzado el curso cuando haya transcurrido aproximadamente el 20% de la duración del curso (requiere que se establezcan las fechas de inicio y fin del curso).'; // Cambiado
$string['progress20emailsubject'] = 'Asunto del Correo de Progreso (20%)'; // Cambiado nombre de string y texto
$string['progress20emailsubject_help'] = 'Asunto para el correo de recordatorio del 20% de progreso. Marcadores de posición: {coursename}, {studentfirstname}, {studentlastname}, {courselink}'; // Cambiado
$string['defaultprogress20subject'] = 'Recordatorio: ¡El curso {coursename} lleva un 20% de progreso!'; // Cambiado nombre de string y texto
$string['progress20emailbody'] = 'Cuerpo del Correo de Progreso (20%) (HTML)'; // Cambiado nombre de string y texto
$string['progress20emailbody_help'] = 'Cuerpo para el correo de recordatorio del 20%. Marcadores de posición: {coursename}, {studentfirstname}, {studentlastname}, {courselink}. Use HTML para el formato.'; // Cambiado
$string['defaultprogress20body'] = '<p>Estimado/a {studentfirstname},</p><p>Solo un recordatorio amigable de que el curso "{coursename}" está en marcha y ya ha transcurrido aproximadamente el 20% de su duración.</p><p>Hemos notado que aún no has comenzado. ¡Todavía hay mucho tiempo para ponerse al día e interactuar con el material!</p><p>Puedes acceder al curso aquí: {courselink}</p><p>¡Esperamos verte en el curso!</p><p>Saludos,<br>El Equipo Docente</p>'; // Cambiado nombre de string y texto
$string['send_progress20_emails_task'] = 'Enviar Correos de Recordatorio del 20% de Progreso del Curso'; // Cambiado nombre de string y texto
// Configuración de Notificación de Finalización de Curso
$string['coursecompletionsettings'] = 'Configuración de Notificación de Finalización de Curso';
$string['enablecompletionemail'] = 'Habilitar correo de finalización de curso';
$string['enablecompletionemail_help'] = 'Si se marca, se enviará un correo a los alumnos cuando completen el curso, según los criterios de finalización de curso de Moodle.';
$string['completionemailsubject'] = 'Asunto del Correo de Finalización de Curso';
$string['completionemailsubject_help'] = 'Asunto para el correo de finalización de curso. Marcadores de posición: {coursename}, {studentfirstname}, {studentlastname}, {courselink}, {completiondate}';
$string['defaultcompletionsubject'] = '¡Felicidades por completar {coursename}!';
$string['completionemailbody'] = 'Cuerpo del Correo de Finalización de Curso (HTML)';
$string['completionemailbody_help'] = 'Cuerpo para el correo de finalización de curso. Marcadores de posición: {coursename}, {studentfirstname}, {studentlastname}, {courselink}, {completiondate}. Use HTML para el formato.';
$string['defaultcompletionbody'] = '<p>Estimado/a {studentfirstname},</p><p>¡Felicidades por completar con éxito el curso "{coursename}" el {completiondate}!</p><p>Te felicitamos por tu arduo trabajo y dedicación.</p><p>Puedes revisar el contenido del curso aquí: {courselink}</p><p>Saludos cordiales,<br>El Equipo Docente</p>';

// Tarea programada
$string['send_completion_emails_task'] = 'Enviar Correos de Finalización de Curso';

// Configuración de Recordatorio de Inicio de Sesión de BBB
$string['bbbupcomingmeetingsettings'] = 'Configuración de Recordatorio de Inicio de Sesión de BigBlueButton';
$string['enablebbbupcomingemail'] = 'Habilitar recordatorio de inicio de sesión de BBB (5 min)';
$string['enablebbbupcomingemail_help'] = 'Si se marca, se enviará un correo a los alumnos matriculados por la mañana si tienen una sesión de BigBlueButton programada para hoy con una hora de inicio definida.';
$string['bbbupcomingemailsubject'] = 'Asunto: Sesión de BBB comenzando pronto';
$string['bbbupcomingemailsubject_help'] = 'Asunto para el recordatorio de inicio de sesión de BBB. Marcadores de posición: {coursename}, {studentfirstname}, {studentlastname}, {sessionname}, {starttime}, {sessionlink}';
$string['defaultbbbupcomingsubject'] = 'Recordatorio: ¡Hoy tienes la sesión {sessionname} en {coursename} a las {starttime}!'; // Añadido {starttime}
$string['bbbupcomingemailbody'] = 'Cuerpo: Sesión de BBB comenzando pronto (HTML)';
$string['bbbupcomingemailbody_help'] = 'Cuerpo para el recordatorio de inicio de sesión de BBB. Marcadores de posición: {coursename}, {studentfirstname}, {studentlastname}, {sessionname}, {starttime}, {sessionlink}. Use HTML para el formato.';
$string['defaultbbbupcomingbody'] = '<p>Estimado/a {studentfirstname},</p><p>Este es un recordatorio de que la sesión de BigBlueButton "<strong>{sessionname}</strong>" en el curso "<strong>{coursename}</strong>" está programada para hoy, a las {starttime}.</p><p>Puedes unirte a la sesión aquí: {sessionlink}</p><p>¡Esperamos verte!</p><p>Saludos,<br>El Equipo Docente</p>';

// Tarea programada
$string['send_bbb_reminder_emails_task'] = 'Enviar Recordatorios Diarios de Sesiones BBB'; // Nombre de tarea más general