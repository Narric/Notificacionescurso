<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'block_course_notifications'; // Nombre completo del plugin (directorio)
$plugin->version   = 2026061900; // O un número mayor que tu versión actual. Ejemplo: YYYYMMDDXX
$plugin->requires  = 2023100900; // Moodle 4.3 (Moodle 5.0 es 2024051300, Moodle 4.1 es 2022112800. Ajusta a tu mínima versión soportada)
$plugin->maturity  = MATURITY_ALPHA; // Estado de desarrollo (ALPHA, BETA, RC, STABLE)
$plugin->release   = 'v0.3.0'; // Versión legible para humanos (actualiza esto también)